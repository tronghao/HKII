<!DOCTYPE html>
<html class="v2" xmlns="http://www.w3.org/1999/xhtml" xmlns:b="http://www.google.com/2005/gml/b" xmlns:data="http://www.google.com/2005/gml/data" xmlns:expr="http://www.google.com/2005/gml/expr" data-sbro-deals-lock="true" style="height: auto;" dir="ltr"><head>
<!-- saved from url=(0045)https://sora-home-soratemplates.blogspot.com/ -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
.gm-style .gm-style-mtc label,.gm-style .gm-style-mtc div{font-weight:400}
</style>
<link type="text/css" rel="stylesheet" href="./Sora%20Home_files/css">
<style type="text/css">
.gm-style .gm-style-cc span,.gm-style .gm-style-cc a,.gm-style .gm-style-mtc div{font-size:10px}
</style>
<style type="text/css">@media print { .gm-style .gmnoprint, .gmnoprint { display:none }}@media screen { .gm-style .gmnoscreen, .gmnoscreen { display:none }}</style>
<style type="text/css">
.gm-style-pbc{transition:opacity ease-in-out;background-color:rgba(0,0,0,0.45);text-align:center}.gm-style-pbt{font-size:22px;color:white;font-family:Roboto,Arial,sans-serif;position:relative;margin:0;top:50%;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}
</style>
<link href="./Sora%20Home_files/2437439463-css_bundle_v2.css" rel="stylesheet" type="text/css">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<script src="./Sora%20Home_files/jquery.min.js.t%E1%BA%A3i+xu%E1%BB%91ng" type="text/javascript"></script>
<link href="./Sora%20Home_files/css%281%29" media="all" rel="stylesheet" type="text/css">
<link href="./Sora%20Home_files/font-awesome.min.css" rel="stylesheet">
<link href="./Sora%20Home_files/icon-font.min.css" rel="stylesheet">
<meta content="blogger" name="generator">
<link href="https://sora-home-soratemplates.blogspot.com/favicon.ico" rel="icon" type="image/x-icon">
<link href="https://sora-home-soratemplates.blogspot.com/" rel="canonical">
<link rel="alternate" type="application/atom+xml" title="Sora Home - Atom" href="https://sora-home-soratemplates.blogspot.com/feeds/posts/default">
<link rel="alternate" type="application/rss+xml" title="Sora Home - RSS" href="https://sora-home-soratemplates.blogspot.com/feeds/posts/default?alt=rss">
<link rel="service.post" type="application/atom+xml" title="Sora Home - Atom" href="https://www.blogger.com/feeds/3971811510442427732/posts/default">
<link rel="openid.server" href="https://www.blogger.com/openid-server.g">
<link rel="openid.delegate" href="https://sora-home-soratemplates.blogspot.com/">
<!--[if IE]><script type="text/javascript" src="https://www.blogger.com/static/v1/jsbin/3658603751-ieretrofit.js"></script> <![endif]-->
<meta content="https://sora-home-soratemplates.blogspot.com/" property="og:url">
<meta content="Sora Home" property="og:title">
<meta content="" property="og:description">
<!--[if IE]> <script> (function() { var html5 = ("abbr,article,aside,audio,canvas,datalist,details," + "figure,footer,header,hgroup,mark,menu,meter,nav,output," + "progress,section,time,video").split(','); for (var i = 0; i < html5.length; i++) { document.createElement(html5[i]); } try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {} })(); </script> <![endif]--><title>Thư Viện DHTV</title>

<!-- Description and Keywords (start) -->
<meta content="YOUR DESCRIPTION HERE" name="description">
<meta content="YOUR KEYWORDS HERE" name="keywords">
<!-- Description and Keywords (end) -->
<meta content="Sora Home" property="og:site_name">
<meta content="https://sora-home-soratemplates.blogspot.com/" name="twitter:domain">
<meta content="" name="twitter:title">
<meta content="summary" name="twitter:card">
<meta content="" name="twitter:title">
<!-- Social Media meta tag need customer customization -->
<meta content="Facebook App ID here" property="fb:app_id">
<meta content="Facebook Admin ID here" property="fb:admins">
<meta content="@username" name="twitter:site">
<meta content="@username" name="twitter:creator">
<style id="page-skin-1" type="text/css">
<!--
/*
-----------------------------------------------
Blogger Template Style
Name: Sora Home
Author : http://www.soratemplates.com
License: Free Version
----------------------------------------------- */
/* Variable definitions
-----------------------
<Group description="Main Hover Color" selector="body">
<Variable name="maincolor" description="Primary Color" type="color" default="#ffbd2f" />
</Group>
/*****************************************
reset.css
******************************************/
html, body, .section, .widget, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, font, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td, figure { margin: 0; padding: 0;}
html { overflow-x: hidden;}
a {text-decoration:none;color:#000;}
article,aside,details,figcaption,figure,
footer,header,hgroup,menu,nav,section { display:block;}
table { border-collapse: separate; border-spacing: 0;}
caption, th, td { text-align: left; font-weight: normal;}
blockquote:before, blockquote:after,
q:before, q:after { content: "";}
.quickedit, .home-link{display:none;}
blockquote, q { quotes: "" "";}
sup{ vertical-align: super; font-size:smaller;}
code{ font-family: 'Courier New', Courier, monospace; font-size:12px; color:#272727;}
::selection {background:transparent; text-shadow:#000 0 0 2px;}
::-moz-selection {background:transparent; text-shadow:#000 0 0 2px;}
::-webkit-selection {background:transparent; text-shadow:#000 0 0 2px;}
::-o-selection {background:transparent; text-shadow:#000 0 0 2px;}
a img{ border: none;}
ol, ul { padding:0; margin:0; text-align: left; }
abbr.published.timeago {
text-decoration: none;
}
ol li { list-style-type: decimal; padding:0 0 5px; }
ul li { list-style-type: disc; padding: 0 0 5px; }
ul ul, ol ol { padding: 0; }
#navbar-iframe, .navbar { height:0px; visibility:hidden; display:none }
.Attribution, .feed-links, .post-footer-line.post-footer-line-1, .post-footer-line.post-footer-line-2 , .post-footer-line.post-footer-line-3 {
display: none;
}
.item-control {
display: none !important;
}
h2.date-header, h4.date-header {display:none;margin:1.5em 0 .5em}
h1, h2, h3, h4, h5, h6 {
font-family: 'Roboto Slab';
font-weight: 400;
color: #151515;
}
img {
max-width: 100%;
vertical-align: middle;
border: 0;
}
.widget iframe, .widget img {
max-width: 100%;
}
.status-msg-wrap {
display: none;
}
#preloader {
position: fixed;
z-index: 1800;
top: 0;
right: 0;
bottom: 0;
left: 0;
width: 100%;
height: 100%;
background: #e74c3c
}
.no-js #preloader,
.oldie #preloader {
display: none
}
.box{
transition: all .2s ease;
}
.loader7{
position:absolute;
width: 40px;
height: 40px;
top: 40%;
top: -webkit-calc(50% - 20px);
top: calc(50% - 20px);
left: 43%;
left: -webkit-calc(50% - 20px);
left: calc(50% - 20px);
background-color: rgba(255, 255, 255, .2);
}
.loader7:before{
content: "";
position: absolute;
background-color: #fff;
height: 10px;
width: 10px;
border-radius: 10px;
-webkit-animation: loader7 2s ease-in-out infinite;
animation: loader7 2s ease-in-out infinite;
}
.loader7:after{
content: "";
position: absolute;
background-color: #fff;
top: 0px;
left: 0px;
height: 40px;
width: 0px;
z-index: 0;
opacity: 1;
-webkit-animation: loader72 10s ease-in-out infinite;
animation: loader72 10s ease-in-out infinite;
}
@-webkit-keyframes loader7{
0%{left: -12px; top: -12px;}
25%{left:42px; top:-12px;}
50%{left: 42px; top: 42px;}
75%{left: -12px; top: 42px;}
100%{left:-12px; top:-12px;}
}
@keyframes loader7{
0%{left: -12px; top: -12px;}
25%{left:42px; top:-12px;}
50%{left: 42px; top: 42px;}
75%{left: -12px; top: 42px;}
100%{left:-12px; top:-12px;}
}
@-webkit-keyframes loader72{
0%{width: 0px;}
70%{width: 40px; opacity: 1;}
90%{opacity: 0; width: 40px;}
100%{opacity: 0;width: 0px;}
}
@keyframes loader72{
0%{width: 0px;}
70%{width: 40px; opacity: 1;}
90%{opacity: 0; width: 40px;}
100%{opacity: 0;width: 0px;}
}
/*****************************************
Custom css starts
******************************************/
body {
color: #2e2e2e;
font-family: Montserrat;
font-size: 14px;
font-weight: normal;
line-height: 21px;
background: #ffffff;
}
/* ######## Wrapper Css ######################### */
#outer-wrapper{max-width:100%;margin:0 auto;background-color:#FFF;box-shadow:0 0 5px RGBA(0, 0, 0, 0.2)}
.row{width:1170px}
#content-wrapper {
margin: 0 auto;
padding: 20px 0 30px;
overflow: hidden;
}
.index #outer-wrapper, .archive #outer-wrapper {
background-color: #f5f5f5;
}
.item #main-wrapper, .statc_page #main-wrapper {
float: left;
width: 68%;
max-width: 800px;
}
.index #main-wrapper, .archive #main-wrapper {
float:none;
width:100%;
max-width:100%
}
.item #sidebar-wrapper, .statc_page #sidebar-wrapper {
float: right;
width: 30%;
max-width: 330px;
}
.index #sidebar-wrapper, .archive #sidebar-wrapper {
display:none;
visibility:hidden;
height:0;
opacity:0;
}
/* ######## Scrolling Navigation Menu Css ######################### */
.scroll-header {
display:none;
}
.item .scroll-header, .static_page .scroll-header, .error_page .scroll-header {
position: static;
display: flex;
background: #f5f5f5 none repeat scroll top left;
box-shadow: 0 0 6px 1px rgba(0,0,0,0.1);
padding: 20px 0;
}
.scroll-head-wrap {
margin:0 auto;
}
.item .scroll-header h1, .static_page .scroll-header h1, .error_page .scroll-header h1 {
display: block!important;
color:#000!important;
}
.item .scroll-header #header img, .static_page .scroll-header #header img, .error_page .scroll-header #header img {
display: none!important;
}
.scrollin-logo {
margin: 0;
padding: 0;
}
.scrollin-logo .logo-title {
font-size: 40px;
font-family: 'Righteous', cursive;
font-weight: bold;
padding: 10px 17px;
display: block;
color:#fff;
}
.scrolling-menu {
float: right;
display: inline-block;
width: auto;
}
.scrolling-menu #nav {
list-style: none;
margin: 0;
padding: 0;
z-index: 999;
}
.scrolling-menu #nav li {
display: inline-block;
float: left;
line-height: 1;
list-style: none outside none;
padding: 16px 17px;
text-align: left;
}
.scrolling-menu #nav li a {
background: transparent;
color: #fff;
display: block;
font-size: 15px;
padding: 0 0 8px;
position: relative;
text-decoration: none;
text-transform: uppercase;
font-weight: bold;
font-family: Montserrat;
letter-spacing: 1.3px;
}
.scrolling-menu #nav li a:hover {
color: #ffbd2f;
}
.scrolling-menu #nav li.current a {
color: #ffbd2f;
}
.scrolling-menu #nav li.current a:before {
position: absolute;
bottom: 0;
left: 0;
width: 100%;
opacity: 1;
height: 1px;
content: '';
-webkit-transition: all ease .3s;
transition: all ease .3s;
background: #ffbd2f;
}
/* ######## Navigation Menu Css ######################### */
.slicknav_menu {
display:none;
}
.slicknav_menu {
right:0;
top:0;
display:none;
}
.scrolling-menu .slicknav_menu {
right:0;
}
.slicknav_menu {
padding:0 10px;
position: absolute;
z-index: 9;
}
.slicknav_menu .slicknav_icon-bar {
background-color: #343434;
}
.index .slicknav_menu .slicknav_icon-bar {
background-color: #fff;
}
.slicknav_nav a{
padding:5px 10px;
margin:2px 5px;
text-decoration:none;
color:#000;
font-size:11px;
font-weight:400;
letter-spacing:2px;
text-transform:uppercase;
font-family: Montserrat;
}
/*
Mobile Menu Core Style
*/
.slicknav_btn { position: relative; display: block; vertical-align: middle; float: right; line-height: 27px; cursor: pointer; height:27px;}
.slicknav_menu .slicknav_menutxt { display: block; line-height: 1.188em; float: left; }
.slicknav_menu .slicknav_icon { float: left; margin: 0.188em 0 0 0.438em; }
.slicknav_menu .slicknav_no-text { margin: 0 }
.slicknav_menu .slicknav_icon-bar { display: block; width: 1.125em; height: 0.125em; }
.slicknav_btn .slicknav_icon-bar + .slicknav_icon-bar { margin-top: 0.188em }
.slicknav_nav { clear: both }
.slicknav_nav ul,
.slicknav_nav li { display: block }
.slicknav_nav .slicknav_arrow { font-size: 0.8em; margin: 0 0 0 0.4em; }
.slicknav_nav .slicknav_item { cursor: pointer; }
.slicknav_nav .slicknav_row { display: block; }
.slicknav_nav a { display: block }
.slicknav_nav .slicknav_item a,
.slicknav_nav .slicknav_parent-link a { display: inline }
.slicknav_menu:before,
.slicknav_menu:after { content: " "; display: table; }
.slicknav_menu:after { clear: both }
.scroll-header.scrolled-header .slicknav_btn {color:#fff;}
.scroll-header.scrolled-header .slicknav_menu .slicknav_icon-bar {
background-color: #fff;
}
/* IE6/7 support */
.slicknav_menu { *zoom: 1 }
/*
User Default Style
Change the following styles to modify the appearance of the menu.
*/
.slicknav_menu {
font-size:16px;
}
/* Button */
.slicknav_btn {
margin: 5px 5px 6px;
text-decoration:none;
text-shadow: 0 1px 1px rgba(255, 255, 255, 0.75);
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
border-radius: 4px;
}
/* Button Text */
.slicknav_menu .slicknav_menutxt {
color: #FFF;
font-weight: bold;
text-shadow: 0 1px 3px #000;
}
/* Button Lines */
.slicknav_nav {
color:#fff;
margin:0;
padding:0;
font-size:0.875em;
background: #fff;
}
.slicknav_nav, .slicknav_nav ul {
list-style: none;
overflow:hidden;
}
.slicknav_nav ul {
padding:0;
margin:8px 0 0 20px;
}
.slicknav_nav .slicknav_row {
padding:5px 10px;
margin:2px 5px;
}
.slicknav_nav .slicknav_item a,
.slicknav_nav .slicknav_parent-link a {
padding:0;
margin:0;
}
.slicknav_nav .slicknav_row:hover {
}
.slicknav_nav a:hover{
color: #ffbd2f;
}
.slicknav_nav .slicknav_txtnode {
margin-left:15px;
}
.slicknav_menu .slicknav_no-text {
margin-top:15px;
}
.tm-menu {
font-weight: 400;
margin: 0;
height:60px;
text-align:center;
width: auto;
background: #29333d;
}
ul#nav1 {
list-style: none;
margin: 0;
padding: 0;
text-align: center;
}
#menu .widget {
display: none;
}
#menu {
height: 60px;
position: relative;
text-align: center;
z-index: 15;
margin:0 auto;
}
.menu-wrap {
margin:0 auto;
position: relative;
}
#menu ul > li {
position: relative;
vertical-align: middle;
display: inline-block;
padding: 0;
margin: 0;
}
#menu ul > li:hover > a {
color: #ffbd2f
}
#menu ul > li > a {
color: #fff;
font-size: 14px;
line-height: 60px;
display: inline-block;
text-transform: uppercase;
text-decoration: none;
letter-spacing: 1px;
margin: 0;
padding: 0 12px;
font-family: Montserrat;
}
.scroll-header.scrolled-header #menu ul > li > a, .scroll-header.scrolled-header #header h1 a {
color:#fff;
}
.scroll-header.scrolled-header #menu ul > li > ul > li > a {
color:#000;
}
#menu ul > li:first-child > a {
padding-left: 0;
}
#menu ul > li > ul > li:first-child > a:before, #menu ul > li > ul > li > ul > li:first-child > a:before {
display:none;
}
#menu ul > li > ul > li:first-child > a {
padding-left: 12px
}
#menu ul > li > ul {
position: absolute;
background: #fff;
-webkit-box-shadow: 0 7px 7px rgba(0, 0, 0, 0.15);
-moz-box-shadow: 0 7px 7px rgba(0, 0, 0, 0.15);
box-shadow: 0 7px 7px rgba(0, 0, 0, 0.15);
top: 100%;
left: 0;
min-width: 180px;
padding: 0;
z-index: 99;
margin-top: 0;
visibility: hidden;
opacity: 0;
webkit-transform: translate3d(-11px, 0, 0);
transform: translate3d(-11px, 0, 0);
-webkit-animation-duration: .5s;
animation-duration: .5s;
}
#menu ul > li > ul > li > ul {
position: absolute;
top: 0;
left: 180px;
width: 180px;
background: #fff;
z-index: 99;
margin-top: 0;
margin-left: 0;
padding: 0;
border-left: 1px solid #e5e5e5;
visibility: hidden;
opacity: 0;
-webkit-transform: translateY(10px);
-moz-transform: translateY(10px);
transform: translateY(10px)
}
#menu ul > li > ul > li {
display: block;
float: none;
text-align: left;
position: relative;
border-bottom: 1px solid;
border-top: none;
border-color: #e5e5e5;
}
#menu ul > li > ul > li:hover {
background-color: rgba(255, 255, 255, 0.03)
}
#menu ul > li > ul > li a {
font-size: 11px;
display: block;
color: #000;
line-height: 35px;
text-transform: uppercase;
text-decoration: none;
margin: 0;
padding: 0 12px;
border-right: 0;
border: 0
}
.index #menu ul > li > ul > li a {
color:#000;
}
#menu ul > li.parent > a:after {
content: '\f107';
font-family: FontAwesome;
float: right;
margin-left: 5px
}
#menu ul > li:hover > ul,
#menu ul > li > ul > li:hover > ul {
opacity: 1;
visibility: visible;
-webkit-transform: translateY(0);
-moz-transform: translateY(0);
transform: translateY(0)
}
#menu ul > li > ul > li.parent > a:after {
content: '\f105';
float: right
}
#menu ul ul {
}
/* ######## Header Css ######################### */
#header-wrapper {
text-align: center;
padding:0;
background: url(https://1.bp.blogspot.com/-lZ5Jy7SQ0mc/WmTJc77tg4I/AAAAAAAAEnM/CGlYzS7etNoeIuLy4HkFRth8KpXXPvLnACLcBGAs/s1600/hero-head-back.jpg) no-repeat center top;
background-attachment: fixed;
background-size: cover;
margin-bottom: 10px;
height:100vh;
box-sizing:border-box;
position:relative;
width: 100%;
}
.index #header-wrapper {
margin-bottom:0;
}
.item .header-logo-desc p, .static_page .header-logo-desc p, .error_page .header-logo-desc p, .item .top-bar-social #social a, .static_page .top-bar-social #social a, .error_page .top-bar-social #social a {
color:#303030;
}
.item #header-wrapper, .static_page #header-wrapper, .error_page #header-wrapper {
background: #fff;
height: auto;
border-bottom: 1px solid #eee;
box-shadow: 0 -2px 19px rgba(0,0,0,.1);
padding-bottom: 15px;
}
.item #header-wrapper:before, .static_page #header-wrapper:before, .error_page #header-wrapper:before {
display:none;
}
#header-wrapper:before {
content:"";
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
opacity: .3;
background: #343434;
}
#header {
padding: 0;
}
#header-inner {
text-align: center;
display: inline-block;
}
#header h1 {
color: #fff;
margin: 0;
font-size: 40px;
line-height: 1.4em;
text-transform: Uppercase;
letter-spacing: 1px;
font-family: 'Righteous', cursive;
}
#header .description {
display:none;
}
.search-css {
position: relative;
padding: 20px 0;
}
.search-css .search-note {
margin: 16px;
text-align: center;
color: #fff;
font-size: 180%;
font-weight: 700;
font-style: normal;
text-transform: uppercase;
letter-spacing: 1px;
font-family: Montserrat;
word-wrap: break-word;
line-height: 1.4;
}
.search-css .search-note .itatu {
font-weight: bold;
border-bottom: 1px solid #fff;
}
.search-css .search-desc {
text-align: center;
color: #fff;
font-size: 15px;
letter-spacing: 1px;
}
.feat-search-wrapper {
color: #fff;
font-size: 16px;
line-height: normal;
margin: 0;
text-align: center;
text-transform: none;
font-weight: 400;
width: 100%;
}
.feat-search-form {
clear: both;
display: block;
overflow: hidden;
margin: 25px auto 0;
}
#searchform fieldset {
float: left;
color: #222;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
box-sizing: border-box;
width: 100%;
border: 0;
}
#searchform fieldset:focus, #searchform fieldset:active {
border: 0;
box-shadow: none;
outline:none;
}
#searchform {
margin: 0px;
display: inline-block;
max-width: 700px;
width: 100%;
}
#s {
float: none;
color: #fff;
background: none;
border: 1px solid #f1f1f1;
margin: 6px auto;
padding: 12px 8px;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
box-sizing: border-box;
width:100%;
clear:both;
}
#searchform .sbutton {
cursor: pointer;
padding: 8px 36px;
float: none;
background: #ffbd2f;
color: #fff;
}
#s:active, #s:focus {
border: 1px solid #f1f1f1;
outline: none;
box-shadow: none;
}
.fenix-head {
display:table;
width:100%;
height:100%;
}
.fenix-sub-head {
margin:0 auto;
display:table-cell;
vertical-align: middle;
}
.index .fenix-sub-head, .archive .fenix-sub-head {
}
.top-bar-social {
padding: 0;
}
.top-bar-social li {
display: inline-block;
float: none;
padding: 0;
margin-right: 5px;
}
.top-bar-social li:last-child {
margin-right:0;
}
.top-bar-social .widget ul {
padding: 0;
}
.top-bar-social .LinkList ul {
text-align: center;
margin: 0 0 0 0;
}
.top-bar-social #social a {
display: block;
width: 30px;
height: 30px;
line-height: 30px;
font-size: 12px;
color: #fff;
border: 1px solid #e4e4e4;
-webkit-border-radius: 100%;
-moz-border-radius: 100%;
border-radius: 100%;
transition: background 0.3s linear;
-moz-transition: background 0.3s linear;
-webkit-transition: background 0.3s linear;
-o-transition: background 0.3s linear;
}
.top-bar-social #social a:before {
display: inline-block;
font: normal normal normal 22px/1 FontAwesome;
font-size: inherit;
font-style: normal;
font-weight: 400;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
}
.top-bar-social .bloglovin:before{content:"\f004"}
.top-bar-social .facebook:before{content:"\f09a"}
.top-bar-social .twitter:before{content:"\f099"}
.top-bar-social .gplus:before{content:"\f0d5"}
.top-bar-social .rss:before{content:"\f09e"}
.top-bar-social .youtube:before{content:"\f167"}
.top-bar-social .skype:before{content:"\f17e"}
.top-bar-social .stumbleupon:before{content:"\f1a4"}
.top-bar-social .tumblr:before{content:"\f173"}
.top-bar-social .vine:before{content:"\f1ca"}
.top-bar-social .stack-overflow:before{content:"\f16c"}
.top-bar-social .linkedin:before{content:"\f0e1"}
.top-bar-social .dribbble:before{content:"\f17d"}
.top-bar-social .soundcloud:before{content:"\f1be"}
.top-bar-social .behance:before{content:"\f1b4"}
.top-bar-social .digg:before{content:"\f1a6"}
.top-bar-social .instagram:before{content:"\f16d"}
.top-bar-social .pinterest:before{content:"\f0d2"}
.top-bar-social .delicious:before{content:"\f1a5"}
.top-bar-social .codepen:before{content:"\f1cb"}
.top-bar-social .bloglovin{background:#ffbd2f}
.top-bar-social .facebook{background:#3b5998}
.top-bar-social .twitter{background:#00aced}
.top-bar-social .gplus{background:#df4b37}
.top-bar-social .rss{background:#f26522}
.top-bar-social .youtube{background:#cd201f}
.top-bar-social .skype{background:#00aff0}
.top-bar-social .stumbleupon{background:#eb4924}
.top-bar-social .tumblr{background:#35465c}
.top-bar-social .vine{background:#00b488}
.top-bar-social .stack-overflow{background:#f48024}
.top-bar-social .linkedin{background:#0077b5}
.top-bar-social .dribbble{background:#ea4c89}
.top-bar-social .soundcloud{background:#ff3300}
.top-bar-social .behance{background:#1769ff}
.top-bar-social .digg{background:#005be2}
.top-bar-social .instagram{background:#c13584}
.top-bar-social .pinterest{background:#bd081c}
.top-bar-social .delicious{background:#3399ff}
.top-bar-social .codepen{background:#47cf73}
.top-bar-social ul#social a:hover {
color: #ffbd2f;
opacity: 1;
}
.slide-in {
font-size: 3.3rem;
position: absolute;
bottom: 7.2rem;
left: 0;
display: block;
width: 100%;
margin: 0;
padding: 0
}
.slide-in .pointer {
position: absolute;
top: 50%;
left: 50%;
width: 26px;
height: 42px;
-webkit-transform: translate(-50%, -50%);
-ms-transform: translate(-50%, -50%);
transform: translate(-50%, -50%);
border: 2px solid #fff;
border-radius: 26px;
-webkit-backface-visibility: hidden
}
.slide-in .pointer:after {
position: absolute;
top: 5px;
left: 50%;
width: 4px;
height: 4px;
margin-left: -2px;
content: '';
-webkit-transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
-webkit-animation: scroll 1.5s -1s cubic-bezier(.68, -.55, .265, 1.55) infinite;
animation: scroll 1.5s -1s cubic-bezier(.68, -.55, .265, 1.55) infinite;
opacity: 1;
border-radius: 100%;
background-color: #fff
}
@-webkit-keyframes scroll {
0%, 20% {
-webkit-transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
transform: translateY(0) scaleY(1) scaleX(1) translateZ(0)
}
10% {
-webkit-transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
opacity: 1
}
to {
-webkit-transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
opacity: .01
}
}
@keyframes scroll {
0%, 20% {
-webkit-transform: translateY(0) scaleY(1) scaleX(1) translateZ(0);
transform: translateY(0) scaleY(1) scaleX(1) translateZ(0)
}
10% {
-webkit-transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
transform: translateY(0) scaleY(1.2) scaleX(1.2) translateZ(0);
opacity: 1
}
to {
-webkit-transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
transform: translateY(20px) scaleY(2.5) scaleX(.5) translateZ(0);
opacity: .01
}
}
@-webkit-keyframes blink {
0%, to {
opacity: 1
}
50% {
opacity: 0
}
}
@keyframes blink {
0%, to {
opacity: 1
}
50% {
opacity: 0
}
}
/* ######## Section 2 Css ######################### */
.sora-works-box {
background: #f1f1f1;
background-size: cover;
overflow: hidden;
margin: 0 auto;
padding:20px 0;
}
.works-wrap {
margin:0 auto;
}
.works-title {
text-align: center;
margin-bottom: 35px;
}
.works-title h4 {
font-size: 35px;
line-height: 45px;
color:#202020;
text-transform:uppercase;
}
.works-title span {
color:#aaa;
}
.works-tiles {
width: 25%;
float: left;
padding: 10px;
box-sizing: border-box;
text-align: center;
}
.works-tiles-wrap-in {
background: #FFF;
box-sizing: border-box;
border-radius: 5px;
padding: 30px 30px 20px;
box-shadow: 5px 5px 45px -27px rgba(0,0,0,0.5);
-webkit-box-shadow: 5px 5px 55px -27px rgba(0,0,0,0.5);
-moz-box-shadow: 5px 5px 45px -27px rgba(0,0,0,0.5);
}
.works-icons {
font-size: 45px;
display: block;
color: #ffbd2f;
margin-bottom: 20px;
}
.works-icons li {
width:60px;
height:60px;
border-radius: 50%;
position: relative;
display: inline-block;
padding: 10px;
list-style:none;
-webkit-transition: all 0.4s ease-in-out;
}
.works-icons li .text {
line-height: 60px;
font-size: 40px;
color:#29333d;
}
.works-heading {
font-size: 18px;
line-height: 21px;
color: #202020;
text-transform: capitalize;
letter-spacing: 1.5px;
margin-bottom: 10px;
font-weight:bold;
}
.works-text {
margin: 0 0 20px;
color: #707070;
}
/* ######## Testimonial Css ######################### */
/*! Flickity v1.0.0
http://flickity.metafizzy.co
---------------------------------------------- */
.flickity-enabled{position:relative}.flickity-enabled:focus{outline:0}.flickity-viewport{overflow:hidden;position:relative;height:100%}.flickity-slider{position:absolute;width:100%;height:100%}.flickity-enabled.is-draggable{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.flickity-enabled.is-draggable .flickity-viewport{cursor:move;cursor:-webkit-grab;cursor:grab}.flickity-enabled.is-draggable .flickity-viewport.is-pointer-down{cursor:-webkit-grabbing;cursor:grabbing}.flickity-prev-next-button{position:absolute;top:50%;width:44px;height:44px; border: 1px solid #d7dbde;background:#fff;background:hsla(0,0%,100%,.75);cursor:pointer;-webkit-transform:translateY(-50%);-ms-transform:translateY(-50%);transform:translateY(-50%)}.flickity-prev-next-button:hover{background:#fff}.flickity-prev-next-button:focus{outline:0;box-shadow:0 0 0 5px #09F}.flickity-prev-next-button:active{filter:alpha(opacity=60);opacity:.6}.flickity-prev-next-button.previous{left:10px}.flickity-prev-next-button.next{right:10px}.flickity-rtl .flickity-prev-next-button.previous{left:auto;right:10px}.flickity-rtl .flickity-prev-next-button.next{right:auto;left:10px}.flickity-prev-next-button:disabled{filter:alpha(opacity=30);opacity:.3;cursor:auto}.flickity-prev-next-button svg{position:absolute;left:20%;top:20%;width:60%;height:60%}.flickity-prev-next-button .arrow{fill:#333}.flickity-prev-next-button.no-svg{color:#333;font-size:26px}.flickity-page-dots{position:absolute;width:100%;bottom:-25px;padding:0;margin:0;list-style:none;text-align:center;line-height:1}.flickity-rtl .flickity-page-dots{direction:rtl}.flickity-page-dots .dot{display:inline-block;width:10px;height:10px;margin:0 8px;background:#efefef;border-radius:50%;filter:alpha(opacity=80);opacity:.80;cursor:pointer; padding: 0;}.flickity-page-dots .dot.is-selected{filter:alpha(opacity=100);opacity:1}
.main-gallery {
background-color: #fff;
}
.main-gallery-wrap {
background-color: #fff;
}
.main-gallery-wrap-in {
margin:0 auto;
}
.gallery-cell {
width: 100%;
}
.testimonial-title {
text-align: center;
margin: 0 0 15px;
padding-top:15px;
}
.testimonial-title h4 {
color: #3d4451;
font-size: 34px;
line-height: 1.2;
font-weight: 600;
text-align: center;
text-transform: uppercase;
}
.testimonial-title .lnr {
margin-right: 5px;
padding: 10px;
box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
color: #3498db;
}
.testimonial {
text-align: left;
max-width: 850px;
margin: 35px auto 40px auto;
padding: 0 20px;
}
.testimonial-image {
float: left;
margin-right: 22px;
}
.testimonial-avatar {
width: 53px;
display: block;
-webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;
}
.person-speech {
font-size: 18px;
font-weight: 400;
line-height: 1.4;
position: relative;
padding-bottom: 27px;
border-bottom: 1px solid #dddad9;
}
.testimonial-quote {
font-size: 22px;
color:#3d4451;
}
.testimonial-quote:before {
content: "\f10e";
top: 2px;
left: -55px;
position: absolute;
font-size: 23px;
line-height: 1;
color:#ffbd2f;
display: inline-block;
font: normal normal normal 22px/1 FontAwesome;
font-size: inherit;
font-style: normal;
font-weight: 400;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
}
.testimonial-meta {
padding-top: 25px;
}
.testimonial-author {
color: #757575;
font-size: 20px;
font-weight: 700;
line-height: 1.1;
display: block;
margin-bottom: 3px;
}
.testimonial-author-details{
color: #d0d0d0;
font-size: 13px;
font-weight: 400;
line-height: 1.1;
text-transform: uppercase;
}
.flickity-page-dots {
bottom: 25px;
}
.flickity-page-dots .dot.is-selected {
background: #ffbd2f;
}
/* ######## Section 3 Css ######################### */
.map-me-full {
width: 100%;
height: 378px;
position: relative;
}
.map-me-full #map {
width: 100%;
height: 378px;
}
.map-me-full .overlay{
position:absolute;
top:10px;
left:10px;
background-color:#3FA9F5;
padding:25px 15px;
text-align:left;
width:230px;
box-sizing:border-box;
}
.map-me-full .overlay h3{
font-size:24px;
font-weight:700;
color:#FFFFFF;
margin-bottom:20px;
text-transform:uppercase
}
.map-me-full .overlay h3 span{
color:#fff
}
.map-me-full .overlay ul li{
color:#ffffff;
font-size:13px;
margin-bottom:10px;
list-style-type:none
}
.map-me-full .overlay ul li strong{
width:80px
}
.map-me-full .overlay ul li span{
font-weight:700;
width:100px;
display:inline-block;
color:#ffffff
}
.map-me-full .overlay ul li.yellow{
color:#ffcc00;
font-weight:800
}
/* ######## Contact Form Css ######################### */
.insta-wrap {
background-color: #004274;
padding-top: 25px;
}
div#sora_blogger_cntct_form {
padding: 50px 0px;
border-radius: 2px;
color: #1D1D1D;
font-size: 15px;
font-weight: bold;
position: relative;
margin:0 auto;
overflow:hidden;
}
div#sora_blogger_cntct_form .wrap-me {
margin: 0;
display: block;
max-width: 500px;
width: 100%;
float: right;
box-sizing: border-box;
padding: 40px 40px 5px;
}
.contact-title {
text-align: center;
margin: 0 0 25px;
}
.contact-title h4 {
font-size: 35px;
line-height: 45px;
color: #fff;
}
.contact-title span {
color: #fefefe;
}
.contact_list_wrapper {
text-align: center;
}
.contact-list-info {
list-style: none;
padding: 0;
margin: 0;
text-align: center;
}
.contact_list_wrapper .contact-list-info li {
padding: 0;
padding-left: 15px;
padding-right: 15px;
display: inline-block;
line-height: 25px;
color: #606060;
}
.contact_list_wrapper .contact-list-info li i {
display: inline;
margin-right: 5px;
font-size: 15px;
vertical-align: -2px;
color: #303030;
}
.contact_list_wrapper .contact-list-info li p {
display: inline;
}
input#ContactForm1_contact-form-name, #ContactForm1_contact-form-email, #ContactForm1_contact-form-email:hover, #ContactForm1_contact-form-email:active {
padding: 5px;
margin-top: 4px !important;
box-shadow: none!Important;
width: 100%;
max-width: 100%;
background: transparent !important;
color: #fff;
border-color: hsla(0,0%,100%,.15) !important;
border-width:0 0 1px 0;
line-height: 1em;
min-height: 31px;
margin-bottom: 15px;
border-radius: 0px;
}
.contact-form-email-message, .contact-form-email-message:active, .contact-form-email-message:hover {
padding: 5px;
margin-top: 4px !important;
box-shadow: none!Important;
width: 100%;
max-width: 100%;
line-height: 1em;
min-height: 80px;
background: transparent !important;
color: #fff;
border-color: hsla(0,0%,100%,.15) !important;
border-width:0 0 1px 0;
margin-bottom: 10px;
border-radius: 0px;
}
/***** Focus *****/
#ContactForm1_contact-form-name:focus, #ContactForm1_contact-form-email:focus, #ContactForm1_contact-form-email-message:focus {
outline: none;
background: transparent !important;
color: #fff;
border-color: #ffbd2f !important;
border-width:0 0 1px 0;
box-shadow: none !important;
transition: all 0.3s ease-in-out !important;
}
/**** Submit button style ****/
.contact-form-button-submit:hover {
color: #FFFFFF;
background: #ffbd2f !important;
color:#000!important;
}
.contact-form-button-submit {
background: transparent;
display: table;
font-size: 17px;
margin: 0 !important;
border-radius: 0 !important;
max-width: 100%;
width: 100%;
min-width: 100%;
height: 32px;
line-height: 0.5em;
letter-spacing: 0.5px;
font-weight: normal;
position:relative;
cursor: pointer;
outline: none!important;
color: #fff;
border: 1px solid #fff !important;
text-align: center;
padding: 0px 25px;
text-transform: capitalize;
transition: all 300ms ease-in-out;
-webkit-transition: all 300ms ease-in-out;
-moz-transition: all 300ms ease-in-out;
}
/**** Submit button on Focus ****/
.contact-form-button-submit:focus, .contact-form-button-submit.focus {
border-color: #ffbd2f;
box-shadow: none !important;
color:#000!important;
}
/**** Error message ****/
.contact-form-success-message, .contact-form-success-message-with-border {
color: #fff !important;
margin-top:55px !important;
}
/**** Submit Button On Success Message ****/
.contact-form-button-submit.disabled, .contact-form-button-submit.disabled:hover, .contact-form-button-submit.disabled:active {
opacity: 0.9;
}
/****** Success Message *****/
.contact-form-error-message-with-border {
background: #000000;
border: 1px solid #5A5A5A;
bottom: 0;
box-shadow: none;
color: #FDFDFD;
font-size: 15px;
font-weight: normal;
line-height: 35px;
margin-left: 0;
opacity: 1;
position: static;
text-align: center;
height: 35px;
margin-top: 60px;
}
.contact-form-cross {
height: 14px;
margin: 5px;
vertical-align: -8.5%;
float: right;
width: 14px;
border-radius: 50px;
border: 0 !important;
cursor: pointer;
}
.contact-form-widget {
max-width: 100%;
}
.contact-form-success-message-with-border {
font-weight: normal;
background-color: #000;
border: 1px solid #FFF;
color: #FFF;
line-height: 35px;
margin-left: 0;
font-size: 13px;
opacity: 1;
position: static;
text-align: center;
height: 35px;
margin-top: 60px;
}
/* Extra Stuff */
div#sora_blogger_cntct_form span.name-bg, div#sora_blogger_cntct_form span.email-bg {
display: inline-block;
line-height: 21px;
width: 100%;
color: hsla(0,0%,100%,.6);
padding: 3px 0;
margin: 0px 0px 4px;
box-sizing: border-box;
height: 30px;
letter-spacing: 1px;
font-weight: normal;
}
div#sora_blogger_cntct_form span.message-bg {
display: inline-block;
line-height: 21px;
width: 100%;
color: hsla(0,0%,100%,.6);
padding: 3px 0;
box-sizing: border-box;
height: 30px;
margin: 0px 0px 4px;
letter-spacing: 1px;
font-weight: normal;
}
div#sora_blogger_cntct_form span.send-bg {
height: 32px;
display: inline-block;
float: left;
transition: all 0.4s ease-in-out !important;
}
div#sora_blogger_cntct_form span.clear-bg {
display: none;
}
input.contact-form-button.contact-form-button-submit.clear-button:hover {
background-color: #E83434 !important;
}
div#sora_blogger_cntct_form .clear-button {
display:none;
}
.map-me {
margin: 0;
display: block;
max-width: 500px;
width: 100%;
float: left;
padding: 40px;
box-sizing: border-box;
}
.map-me .con-title {
font-weight: 700;
letter-spacing: -1px;
line-height: 48px;
color: #fff;
margin: 0;
text-transform: capitalize;
}
.map-me .con-text {
font-weight: 100;
line-height: 24px;
color: #fefefe;
margin: 0 0 10px;
}
.map-me .con-list {
list-style-type: none;
padding: 0;
}
.map-me .con-list li {
list-style-type: none;
color: #fff;
line-height: 45px;
margin-bottom: 15px;
font-weight:normal;
}
.map-me .con-list li i {
font-size: 1em;
margin-right: 20px;
padding: 15px;
-webkit-box-pack: center;
-ms-flex-pack: center;
justify-content: center;
background: #000;
color: #fff;
}
/* ######## Sidebar Css ######################### */
.sidebar .widget {
margin-bottom: 20px;
position: relative;
background: #f5f5f5 none repeat scroll top left;
box-shadow: 0px 2px 6px 0px rgba(0,0,0,0.1);
}
.sidebar h2 {
font-size: 17px;
line-height: 27px;
color: #000;
padding: 7px 15px;
font-weight: 400;
letter-spacing: 1.5px;
text-transform: uppercase;
position: relative;
text-align: center;
background: #f7f7f7;
border: 1px solid #f0f0f0;
}
.sidebar .widget-content {
padding: 10px;
box-sizing:border-box;
}
.sidebar ul,.sidebar li{
list-style-type:none;
margin:0;
}
/* ######## Counter Css ######################### */
.counter-box {
background: url(//2.bp.blogspot.com/-wXGrHXHyBfg/WmTLRWUWxmI/AAAAAAAAEnk/gWXx9_Zp2108zlj-1cdcl1UF17F0z6fRgCK4BGAYYCw/s1600/hero-head.jpg) no-repeat;
background-attachment: scroll;
background-size: cover;
background-position: 50% 0;
overflow: hidden;
margin: 0 auto;
padding: 40px 0;
position:relative;
}
.counter-box:before {
background: rgba(0, 0, 0, 0.7);
content: "";
position: absolute;
display: block;
left: 0;
top: 0;
width: 100%;
height: 100%;
bottom: 0;
}
.counter-box-wrap {
margin: 0 auto;
}
.counter-title {
text-align: center;
margin-bottom: 35px;
}
.counter-title h4 {
font-size: 35px;
line-height: 45px;
color: #fff;
text-transform: uppercase;
}
.counter-title span {
color: #fefefe;
}
.counter-box-item {
width: 25%;
float: left;
padding: 10px;
box-sizing: border-box;
text-align: center;
color: #fff;
position: relative;
}
.counter-box-item .lnr {
font-size: 24px;
}
.counter-sora {
color:#fff;
font-size: 48px;
line-height: 48px;
font-weight: 700;
margin: 10px 0;
-webkit-transition: all 300ms linear;
-moz-transition: all 300ms linear;
-o-transition: all 300ms linear;
transition: all 300ms linear;
font-family: 'Righteous', cursive;
}
.counter-sora-text {
font-size: 14px;
text-transform: uppercase;
letter-spacing: 3px;
color: #fff;
}
/* ######## Featured Summary Css ######################### */
.tybox-wrapper {
margin: 0 0 10px;
overflow:hidden;
}
.featured-box {
clear: both;
}
.box-menu-tab {
position: relative;
clear: both;
width: 100%;
}
.tybox-wrapper .tyboxtabs .box-menu-tab li {
padding: 0;
list-style: none;
float: left;
}
.tybox-wrapper .tyboxtabs .box-menu-tab .box-head-title {
height: 30px;
line-height: 30px;
padding: 5px 10px;
font-size: 13px;
transition: color .3s ease-out;
background: #29333d;
float: left;
}
.tybox-wrapper .tyboxtabs .box-menu-tab .box-head-title a {
color: #fff;
text-transform: uppercase;
font-weight: 700;
}
.tybox-wrapper .tyboxtabs .box-menu-tab .active .box-head-title {
background: #ffbd2f;
}
.tybox-wrapper .tyboxtabs .box-menu-tab .box-head-more {
position: absolute;
right: 0;
height: 30px;
line-height: 30px;
padding: 5px 10px;
font-size: 13px;
transition: color .3s ease-out;
display:none;
}
.yard-auth-ty::before {
content: '\f007';
font-family: fontawesome;
color: #bbb;
margin-right: 5px;
}
.yard-auth-ty {
margin-right: 10px;
}
.yard-auth-ty, .ty-time {
color: #bdbdbd;
font-size: 12px;
font-weight: 400;
}
.tybox-wrapper .tyboxtabs .box-menu-tab .active .box-head-more {
display: inline-block;
}
.tybox-wrapper .tyboxtabs .box-menu-tab .box-head-more a:before {
display: inline-block;
margin-right: 5px;
width: 8px;
height: 8px;
border-radius: 50%;
background-color: #ffbd2f;
content: '';
vertical-align: baseline;
padding: 0;
}
.tybox .tybox-first {
width: 50%;
position: relative;
float: left;
padding-right: 1.4%;
box-sizing: border-box;
overflow: hidden;
}
.tybox .tybox-feat-image {
width: 100%;
position: relative;
overflow: hidden;
padding:10px;
box-sizing:border-box;
background:#ffbd2f;
}
.tybox .tybox-first .tyard-thumb, .tybox .tybox-img {
height: 250px !important;
transition: all .3s ease-in-out;
}
.templatesyard .tyard-thumb:hover .tybox-img, .templatesyard .tyard-thumb:hover .yard-img, .templatesyard .tylist-first .tyard-thumb:hover .tylist-img, .templatesyard .col-left-first .tyard-thumb:hover .col-left-img, .templatesyard .col-right-first .tyard-thumb:hover .col-right-img, .templatesyard .ty-feat .tygrid-rest .tygrid-thumb:hover .yard-img, .post-home-image .post-thumb:hover a {
transform: scale(1.1) rotate(-1deg);
transition: all .3s ease-in-out;
}
.templatesyard .tyard-thumb .tybox-img, .templatesyard .tyard-thumb .yard-img, .templatesyard .tylist-first .tyard-thumb .tylist-img, .templatesyard .col-left-first .tyard-thumb .col-left-img, .templatesyard .col-right-first .tyard-thumb .col-right-img, .templatesyard .ty-feat .tygrid-rest .tygrid-thumb .yard-img, .post-home-image .post-thumb a {
transition: all .3s ease-in-out;
}
.templatesyard .tybox-first .tyard-thumb {
position: relative;
width: 100%;
height: 250px;
}
.templatesyard .tybox-img {
width: 100%;
height: 200px;
position: relative;
display: block;
}
.tybox-first .tyard-thumb .yard-label {
}
.tybox-first .tyard-thumb .yard-label a {
background: #ffbd2f;
color: #fff;
text-transform: uppercase;
height: 20px;
line-height: 20px;
display: inline-block;
padding: 0 6px;
font-size: 11px;
font-weight: 400;
border-radius: 2px;
}
.tybox .tybox-con-yard {
position: absolute;
bottom: 0;
width: 100%;
z-index: 2;
padding: 15px;
box-sizing: border-box;
}
.tybox .tybox-first .tybox-con-yard .tyard-title a {
display: block;
font-size: 19px;
color: #fff;
font-weight: 400;
line-height: 1.4em;
margin-bottom: 5px;
margin-top: 5px;
}
.tybox .tybox-first .recent-summary {
color: #fff;
font-size: 14px;
font-weight: normal;
}
.tybox-more {
background: #3d3d3d;
padding: 5px 12px !important;
display: inline-block;
vertical-align: middle;
margin: 0;
font-size: 12px;
text-transform: capitalize;
border-radius: 2px;
color: #f7f7f7;
font-weight: 700;
white-space: nowrap;
font-family:Ruda;
}
.tybox .ty-feat .tybox-rest.first-box {
width: 60%;
position: relative;
float: left;
overflow: hidden;
margin: 0;
padding-right: 2%;
box-sizing: border-box;
}
.tybox .ty-feat .tybox-rest.first-box .first-box-wrp {
overflow: hidden;
position: relative;
}
.tybox .ty-feat .tybox-rest {
margin-bottom: 10px;
overflow: hidden;
display: block;
padding: 0;
position: relative;
}
.templatesyard .ty-feat .tybox-rest .tyard-thumb {
position: relative;
float: left;
width: 100%;
height: auto;
overflow: hidden;
display: block;
vertical-align: middle;
margin: 0 !important;
}
.templatesyard .ty-feat .tybox-rest.first-box .yard-img {
height:430px;
}
.templatesyard .ty-feat .tybox-rest .yard-img {
width: 100%;
height: 210px;
position: relative;
display: block;
transition: all .3s ease-in-out;
}
.templatesyard .ty-feat .tybox-rest.first-box .tyard-thumb:before {
content: "\f0f6";
font-family: FontAwesome;
line-height: 25px;
width: 25px;
height: 25px;
font-size: 12px;
color: #fff;
text-align: center;
background-color: RGBA(0,0,0,0.4);
font-weight: 400;
position: absolute;
top: 8px;
opacity: 0.5;
right: 7px;
z-index: 2;
padding: 0;
border: 2px solid #fff;
border-radius: 50%;
-webkit-transition: all 500ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
transition: all 500ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
}
.templatesyard .ty-feat .tybox-rest .tyard-thumb:hover:before {
background-color: #ffbd2f;
border-color:#ffbd2f;
-webkit-box-shadow: 0 3px 5px rgba(0, 0, 0, 0.25);
-moz-box-shadow: 0 3px 5px rgba(0, 0, 0, 0.25);
box-shadow: 0 3px 5px rgba(0, 0, 0, 0.25);
opacity:1;
top: 40%;
right: 40%;
width: 50px;
height: 50px;
line-height: 50px;
font-size: 24px;
}
.tybox .tyimg-lay {
position: absolute;
left: 0;
top:50%;
bottom: 0;
z-index: 1;
width: 100%;
height: 50%;
opacity:0.5;
background: -moz-linear-gradient(top,rgba(34,34,34,0) 0%,rgba(34,34,34,.25) 30%,rgba(34,34,34,.8) 100%);
background: -webkit-gradient(linear,left top,left bottom,color-stop(0%,rgba(34,34,34,0)),color-stop(30%,rgba(34,34,34,.25)),color-stop(100%,rgba(34,34,34,.8)));
background: -webkit-linear-gradient(top,rgba(34,34,34,0) 0%,rgba(34,34,34,.25) 30%,rgba(34,34,34,.8) 100%);
background: -o-linear-gradient(top,rgba(34,34,34,0) 0%,rgba(34,34,34,.25) 30%,rgba(34,34,34,.8) 100%);
background: -ms-linear-gradient(top,rgba(34,34,34,0) 0%,rgba(34,34,34,.25) 30%,rgba(34,34,34,.8) 100%);
background: linear-gradient(to bottom,rgba(34,34,34,0) 0%,rgba(34,34,34,.25) 30%,rgba(34,34,34,.8) 100%);
}
.tybox .yard-tent-ty {
position: absolute;
bottom: 0;
width: 100%;
z-index: 2;
padding: 15px;
box-sizing: border-box;
background: #282828;
}
.tybox .yard-tent-ty .yard-label {
z-index: 2;
}
.tybox .yard-tent-ty .yard-label {
color: #fff;
text-transform: uppercase;
height: 20px;
line-height: 20px;
display: inline-block;
padding:0;
font-size: 11px;
font-weight: 400;
margin-bottom: 8px;
}
.tybox .yard-tent-ty .yard-label a {
color:#fff;
}
.tybox .yard-tent-ty .yard-label a:before {
display: inline-block;
margin-right: 5px;
width: 8px;
height: 8px;
border-radius: 50%;
background-color: #ff4545;
content: '';
vertical-align: baseline;
padding: 0;
}
.tybox .yard-tent-ty .tyard-title {
overflow: hidden;
line-height: 0;
margin: 0 0 2px;
padding: 0;
}
.tybox .ty-feat .tybox-rest.first-box .yard-tent-ty .tyard-title a {
font-size: 22px;
line-height: 1.2;
}
.tybox .yard-tent-ty .tyard-title a {
color: #fff;
font-weight: 700;
font-size: 16px;
line-height: 1.5em;
letter-spacing: 1px;
}
.tybox-time {
color: #bdbdbd;
font-size: 12px;
font-weight: 400;
}
.tybox-time:before {
content: '\f133';
font-family: fontawesome;
color: #bbb;
margin-right: 5px;
}
.tybox .ty-feat .tybox-rest:nth-child(3) {
margin-bottom: 0;
}
.tybox .tyard-thumb .item-cmm {
position: absolute;
top: 0;
left: 10px;
z-index: 2;
color: #fff;
text-transform: uppercase;
height: 20px;
line-height: 20px;
display: inline-block;
padding: 5px 6px 0;
font-size: 12px;
font-weight: bold;
background: #ffbd2f;
border-radius: 0 0 2px 2px;
}
.tybox .tyard-thumb .item-cmm:before {
content: "\f086";
margin-right: 5px;
font-family: FontAwesome;
font-style: normal;
font-weight: normal;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
}
.tybox .category-gallery {
position: absolute;
top: 10px;
right: 10px;
z-index: 3;
overflow: hidden;
}
.tybox .category-gallery a:before {
display: block;
background-color: #e74c3c;
opacity: .5;
color: #fff;
height: 18px;
line-height: 18px;
padding: 0 5px;
font-size: 10px;
font-weight: 400;
text-transform: uppercase;
border-radius: 2px;
transition: all .3s ease;
}
.icon:before {
font-family: FontAwesome;
font-weight: 400;
font-style: normal;
line-height: 1;
padding-right: 4px;
}
.tysum-wrapper .featured-box {
margin: 0 auto;
overflow: hidden;
}
.tyheading-head {
text-align: center;
margin: 25px 0;
}
.tyheading-head h2 {
font-size: 35px;
line-height: 45px;
color: #303030;
text-transform: capitalize;
}
.tysum .ty-feat .tybox-rest {
float: left;
width: 25%;
padding-right: 10px;
box-sizing: border-box;
margin-bottom:10px;
position:relative;
}
.tysum .ty-feat .tybox-rest:nth-child(4n) {
padding-right: 0;
}
.tysum .tyimg-lay {
position: absolute;
left: 0;
top: 0;
z-index: 1;
width: 100%;
height: 100%;
opacity:0.5;
background: -webkit-linear-gradient(top, rgba(0, 0, 0, 0.3) 50%, rgba(0, 0, 0, 0.6) 70%, rgba(0, 0, 0, 1) 100%);
background: -moz-linear-gradient(top, rgba(0, 0, 0, 0.3) 50%, rgba(0, 0, 0, 0.6) 70%, rgba(0, 0, 0, 1) 100%);
background: -ms-linear-gradient(top, rgba(0, 0, 0, 0.3) 50%, rgba(0, 0, 0, 0.6) 70%, rgba(0, 0, 0, 1) 100%);
background: -o-linear-gradient(top, rgba(0, 0, 0, 0.3) 50%, rgba(0, 0, 0, 0.6) 70%, rgba(0, 0, 0, 1) 100%);
background: linear-gradient(top, rgba(0, 0, 0, 0.3) 50%, rgba(0, 0, 0, 0.6) 70%, rgba(0, 0, 0, 1) 100%);
}
.tysum .yard-tent-ty {
clear: both;
z-index: 2;
padding: 10px 0 0;
box-sizing: border-box;
}
.tysum .yard-tent-ty .tyard-title {
overflow: hidden;
line-height: 0;
margin: 0 0 2px;
padding: 0;
}
.tysum .yard-tent-ty .tyard-title a {
color: #2e2e2e;
font-weight: 700;
font-size: 16px;
line-height: 1.5em;
letter-spacing: 1px;
}
.tysum .yard-tent-ty .recent-summary {
color: #6a6a6a;
line-height: 20px;
font-size: 13px;
font-weight: normal;
}
.tysum.templatesyard .ty-feat .tybox-rest .yard-img {
height: 185px;
}
.tysum-wrapper {
overflow: hidden;
background: #fff;
padding: 0 0 25px;
}
/* ######## Post Css ######################### */
.Portfolio-title {
text-align: center;
margin: 25px 0;
}
.Portfolio-title h4 {
font-size: 35px;
line-height: 45px;
color: #303030;
text-transform:capitalize;
}
.Portfolio-title span {
color: #606060;
}
article {
padding: 0;
overflow:hidden;
}
.index .post-grid-item, .archive .post-grid-item {
width:33.33%;
float:left;
padding-right:15px;
box-sizing:border-box;
margin-bottom:15px;
}
.index .post-grid-item:nth-child(3n), .archive .post-grid-item:nth-child(3n) {
padding-right:0;
}
.post {
display: block;
word-wrap: break-word;
background: #ffffff;
}
.post h1 {
color: #0a0a0a;
font-size: 28px;
font-weight: 400;
line-height: 32px;
margin: 0 0 10px;
}
.post h2 {
margin-bottom: 12px;
line-height: 24px;
font-size: 18px;
font-weight:700;
}
.post h2 a {
color: #000;
letter-spacing: 1px;
}
.post h2 {
margin: 0 0 10px;
padding: 0;
}
.retitle h2 {
margin:0 0 8px;
display: block;
}
.post-body {
margin: 0px;
padding:10px;
font-size: 14px;
line-height: 26px;
box-sizing:border-box;
text-align:justify;
}
.block-image {
float: left;
width: 100%;
height:auto;
position:relative;
padding: 10px;
box-sizing: border-box;
}
.block-image .thumb {
width: 100%;
height: auto;
position: relative;
display: block;
overflow: hidden;
}
.block-image .thumb:before {
background: rgba(0, 0, 0, 0.5);
bottom: 0px;
content: "";
height: 100%;
width: 100%;
left: 0px;
right: 0px;
margin: 0px auto;
position: absolute;
opacity:0;
z-index: 3;
}
.block-image img {
width: 100%;
height: 245px;
display: block;
object-fit:cover;
transition: all .3s ease-out!important;
-webkit-transition: all .3s ease-out!important;
-moz-transition: all .3s ease-out!important;
-o-transition: all .3s ease-out!important;
}
.block-image:hover .thumb:before {
opacity:1;
}
.post-header {
padding: 0 10px 10px;
}
.post-meta {
color: #bdbdbd;
display: block;
font-size: 13px;
font-weight: 400;
line-height: 21px;
margin: 0;
padding: 0;
}
.post-meta a, .post-meta i {
color: #CBCBCB;
}
.post-timestamp {
margin-left: 5px;
}
.label-head {
margin-left: 5px;
}
.label-head a {
padding-left: 2px;
}
.resumo {
margin-top: 10px;
color: #919191;
}
.resumo span {
display: block;
margin-bottom: 8px;
font-size: 16px;
line-height: 31px;
}
#meta-post .post-labels {
font-size: 13px;
line-height: 43px;
font-weight: 600;
}
#meta-post .read-more {
color: #fff;
float: right;
background-color: #00AEEF;
border: 1px solid #00AEEF;
outline: 0!important;
display: inline-block;
margin-bottom: 0;
font-weight: 500;
text-align: center;
vertical-align: middle;
white-space: nowrap;
padding: 11px 15px;
font-size: 14px;
line-height: 1.42857;
border-radius: 4px;
position:relative;
}
#meta-post .read-more:after {
content: '\f105';
font-family: FontAwesome;
float: right;
margin-left: 5px;
}
#bottom-meta-post {
border-top: 1px solid #e5e5e5;
padding: 14px 20px;
box-sizing: border-box;
}
#bottom-meta-post .post-timestamp {
float: right;
}
.post-body img {
max-width: 100%;
padding: 10px 0;
position: relative;
margin:0 auto;
}
.post h3 {
font-size: 18px;
margin-top: 20px;
margin-bottom: 10px;
line-height: 1.1;
}
.second-meta {
display: none;
}
.comment-link {
white-space: normal;
}
.ias_trigger {
clear: both;
text-align: center;
}
.ias_trigger a {
padding: 8px;
color: #fff;
background: #222;
border-radius: 4px;
}
.ias_trigger a:hover {
background:#ffbd2f;
}
#blog-pager {
clear: both;
text-align: center;
padding: 15px 0;
background: #ffffff;
color: #4d4d4d;
}
.displaypageNum a,
.showpage a,
.pagecurrent, .blog-pager-older-link, .blog-pager-newer-link {
padding: 5px 13px;
margin-right: 8px;
color: #fff;
background-color: #2b2b2b;
display: inline-block;
line-height: 20px;
-moz-border-radius: 2px;
-webkit-border-radius: 2px;
border-radius: 2px;
}
.displaypageNum a:hover,
.showpage a:hover,
.pagecurrent, .blog-pager-older-link:hover, .blog-pager-newer-link:hover {
background: #ffbd2f;
text-decoration: none;
color: #fff;
}
.showpageOf {
display: none!important;
overflow: hidden;
}
#blog-pager .pages {
margin: 10px 0;
border: none;
}
/* ######## Share widget Css ######################### */
.item .post-footer {
padding: 0 10px;
}
.share-box {
position: relative;
padding: 10px 0;
}
.share-title {
border-bottom: 2px solid #777;
color: #010101;
display: inline-block;
padding-bottom: 7px;
font-size: 15px;
font-weight: 500;
position: relative;
top: 2px;
}
.share-art {
float: right;
padding: 0;
padding-top: 0;
font-size: 13px;
font-weight: 400;
text-transform: capitalize;
}
.share-art a {
color: #fff;
padding: 3px 8px;
margin-left: 4px;
border-radius: 2px;
display: inline-block;
margin-right: 0;
background: #010101;
}
.share-art a span {
display: none;
}
.share-art a:hover{color:#fff}
.share-art .fac-art{background:#3b5998}
.share-art .fac-art:hover{background:rgba(49,77,145,0.7)}
.share-art .twi-art{background:#00acee}
.share-art .twi-art:hover{background:rgba(7,190,237,0.7)}
.share-art .goo-art{background:#db4a39}
.share-art .goo-art:hover{background:rgba(221,75,56,0.7)}
.share-art .pin-art{background:#CA2127}
.share-art .pin-art:hover{background:rgba(202,33,39,0.7)}
.share-art .lin-art{background:#0077B5}
.share-art .lin-art:hover{background:rgba(0,119,181,0.7)}
.share-art .wat-art{background:#25d266;display:none;}
.share-art .wat-art:hover{background:rgba(37, 210, 102, 0.73)}
@media only screen and (max-width: 768px) {
.share-art .wat-art{display:inline-block;}
}
/* ######## Related Post Css ######################### */
#related-posts {
margin-bottom: 10px;
padding: 10px 0;
}
.related li {
width: 32%;
display: inline-block;
height: auto;
min-height: 184px;
float: left;
margin-right: 10px;
overflow: hidden;
position: relative;
}
.related li h3 {
margin-top:0;
}
.related-thumb {
width: 100%;
height: 100px;
overflow: hidden;
border-radius: 2px;
}
.related li .related-img {
width: 100%;
height: 100px;
display: block;
position: relative;
transition: all .3s ease-out!important;
-webkit-transition: all .3s ease-out!important;
-moz-transition: all .3s ease-out!important;
-o-transition: all .3s ease-out!important;
}
.related li .related-img:hover {
-webkit-transform: scale(1.1) rotate(-1.5deg)!important;
-moz-transform: scale(1.1) rotate(-1.5deg)!important;
transform: scale(1.1) rotate(-1.5deg)!important;
transition: all .3s ease-out!important;
-webkit-transition: all .3s ease-out!important;
-moz-transition: all .3s ease-out!important;
-o-transition: all .3s ease-out!important;
}
.related-title a {
font-size: 12px;
line-height: 1.4em;
padding: 10px 0 0;
font-weight: 400;
font-style: normal;
letter-spacing: 1px;
color: #010101;
display: block;
}
.related li:nth-of-type(3n) {
margin-right: 0;
}
.related .related-tag {
display:none;
}
.related-overlay {
position: absolute;
left: 0;
top: 0;
z-index: 1;
width: 100%;
height: 100%;
background-color: rgba(40,35,40,0.05);
}
.related-content {
display: block;
bottom: 0;
padding: 0px 0px 11px;
width: 100%;
line-height: 1.2em;
box-sizing: border-box;
z-index: 2;
}
.related .related-content .recent-date {
font-size: 10px;
}
.recent-date:before, .p-date:before {
content: '\f017';
font-family: fontawesome;
margin-right: 5px;
}
/* ######## Comment Widget Css ######################### */
.comments {
clear: both;
margin: 0;
color: #48494d;
margin-top:10px;
box-sizing: border-box;
border-radius: 5px;
padding: 30px 30px 20px;
background: #FFF;
}
.post-feeds .feed-links {
display: none;
}
iframe.blogger-iframe-colorize,
iframe.blogger-comment-from-post {
height: 260px!important;
background: #fff;
}
.comment-form {
overflow:hidden;
}
.comments h3 {
line-height:normal;
text-transform:uppercase;
color:#333;
font-weight:bold;
margin:0 0 20px 0;
font-size:14px;
padding:0 0 0 0;
}
h4#comment-post-message {
display:none;
margin:0 0 0 0;
}
.comments h4{
color: #48494d;
border-bottom: 1px solid #efefef;
font-size: 16px;
padding: 12px 0;
margin: 0;
font-weight: 700;
letter-spacing: 1.5px;
text-transform: uppercase;
position: relative;
text-align: left;
}
.comments h4:after {
display: inline-block;
content: "\f075";
font-family: fontAwesome;
font-style: normal;
font-weight: normal;
font-size: 18px;
color: #ffbd2f;
top: 12px;
right: 15px;
padding: 0;
position: absolute;
}
.comments .comments-content{
font-size:13px;
margin-bottom:8px;
padding: 0;
}
.comments .comments-content .comment-thread ol{
list-style:none;
text-align:left;
margin:13px 0;
padding:0
}
.comments .comments-content .comment-thread ol li{
list-style:none;
}
.comments .avatar-image-container {
background:#fff;
border:1px solid #DDD;
overflow:hidden;
padding:0;
border-radius: 50%;
}
.comments .avatar-image-container img {
border-radius:50%;
}
.comments .comment-block{
position:relative;
background:#fff;
padding:15px;
margin-left:60px;
border: 1px solid #efefef;
}
.comments .comment-block:before {
content:"";
width:0px;
height:0px;
position:absolute;
right:100%;
top:14px;
border-width:10px;
border-style:solid;
border-color:transparent #DDD transparent transparent;
display:block;
}
.comments .comments-content .comment-replies{
margin:8px 0;
margin-left:60px
}
.comments .comments-content .comment-thread:empty{
display:none
}
.comments .comment-replybox-single {
background:#f0f0f0;
padding:0;
margin:8px 0;
margin-left:60px
}
.comments .comment-replybox-thread {
background:#f0f0f0;
margin:8px 0 0 0;
padding:0;
}
.comments .comments-content .comment{
margin-bottom:6px;
padding:0
}
.comments .comments-content .comment:first-child {
padding:0;
margin:0
}
.comments .comments-content .comment:last-child {
padding:0;
margin:0
}
.comments .comment-thread.inline-thread .comment, .comments .comment-thread.inline-thread .comment:last-child {
margin:0px 0px 5px 30%
}
.comment .comment-thread.inline-thread .comment:nth-child(6) {
margin:0px 0px 5px 25%;
}
.comment .comment-thread.inline-thread .comment:nth-child(5) {
margin:0px 0px 5px 20%;
}
.comment .comment-thread.inline-thread .comment:nth-child(4) {
margin:0px 0px 5px 15%;
}
.comment .comment-thread.inline-thread .comment:nth-child(3) {
margin:0px 0px 5px 10%;
}
.comment .comment-thread.inline-thread .comment:nth-child(2) {
margin:0px 0px 5px 5%;
}
.comment .comment-thread.inline-thread .comment:nth-child(1) {
margin:0px 0px 5px 0;
}
.comments .comments-content .comment-thread{
margin:0;
padding:0
}
.comments .comments-content .inline-thread{
background: #fff;
padding:15px;
box-sizing:border-box;
margin:0
}
.comments .comments-content .inline-thread .comment-block {
border-color: #ffbd2f;
}
.comments .comments-content .inline-thread .comment-block:before {
border-color: transparent #ffbd2f transparent transparent;
}
.comments .comments-content .user {
letter-spacing: 0.5px;
font-weight: 600;
}
.comments .comments-content .icon.blog-author {
display:inline;
}
.comments .comments-content .icon.blog-author:after {
content: "Author";
background:#ffbd2f;
color: #fff;
font-size: 11px;
padding: 2px 5px;
text-transform:Capitalize;
font-style:italic;
letter-spacing: 0.3px;
}
.comment-header {
text-transform:uppercase;
font-size:12px;
}
.comments .comments-content .datetime {
margin-left: 6px;
}
.comments .comments-content .datetime a {
color:#888;
}
.comments .comment .comment-actions a {
display:inline-block;
color:#333;
font-weight:bold;
font-size:10px;
line-height:15px;
margin:4px 8px 0 0;
}
.comments .continue a {
color:#333;
display:inline-block;
font-size:10px;
}
.comments .comment .comment-actions a:hover, .comments .continue a:hover{
text-decoration:underline;
}
/* ######## Instagram Widget Css ######################### */
/* ######## Footer Css ######################### */
.bot-bar-menu {
background-color: #00335A;
border-top: 1px solid #00243f;
padding: 20px 0px;
overflow: hidden;
}
.bot-menu-wrap {
margin: 0 auto;
position:relative;
text-align:center;
}
.bot-menu {
position: absolute;
left: 0;
top: 8px;
}
.bot-menu h2 {
display:none;
}
.bot-menu ul {
overflow: hidden;
list-style: none;
padding: 0;
margin: 0;
}
.bot-menu ul li {
float: left;
display: inline-block;
list-style: none;
padding: 0;
}
.bot-menu ul li a {
padding: 10px 16px;
display: block;
border: none !important;
text-decoration: none;
line-height: inherit;
font-size: 14px;
font-weight: normal;
color: #eeeeee;
text-transform: uppercase;
}
.bot-menu ul li a:hover {
color:#ffbd2f;
}
.bottom-bar-social {
position: absolute;
right: 0;
top: 8px;
}
.bottom-bar-social li {
display: inline;
padding: 0;
float: left;
margin-right: 5px;
;
}
.bottom-bar-social .widget ul {
padding: 0;
}
.bottom-bar-social .LinkList ul {
text-align: center;
}
.bottom-bar-social #social a {
display: block;
font-size: 14px;
color: #fff;
padding: 10px 5px;
}
.bottom-bar-social #social a:before {
display: inline-block;
font: normal normal normal 22px/1 FontAwesome;
font-size: inherit;
font-style: normal;
font-weight: 400;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
}
.bottom-bar-social .bloglovin:before{content:"\f004"}
.bottom-bar-social .facebook:before{content:"\f09a"}
.bottom-bar-social .twitter:before{content:"\f099"}
.bottom-bar-social .gplus:before{content:"\f0d5"}
.bottom-bar-social .rss:before{content:"\f09e"}
.bottom-bar-social .youtube:before{content:"\f167"}
.bottom-bar-social .skype:before{content:"\f17e"}
.bottom-bar-social .stumbleupon:before{content:"\f1a4"}
.bottom-bar-social .tumblr:before{content:"\f173"}
.bottom-bar-social .vine:before{content:"\f1ca"}
.bottom-bar-social .stack-overflow:before{content:"\f16c"}
.bottom-bar-social .linkedin:before{content:"\f0e1"}
.bottom-bar-social .dribbble:before{content:"\f17d"}
.bottom-bar-social .soundcloud:before{content:"\f1be"}
.bottom-bar-social .behance:before{content:"\f1b4"}
.bottom-bar-social .digg:before{content:"\f1a6"}
.bottom-bar-social .instagram:before{content:"\f16d"}
.bottom-bar-social .pinterest:before{content:"\f0d2"}
.bottom-bar-social .delicious:before{content:"\f1a5"}
.bottom-bar-social .codepen:before{content:"\f1cb"}
.bottom-bar-social ul#social a:hover {
color: #ffbd2f;
opacity: 1;
}
.jugas_footer_copyright {
display: inline-block;
color: #fff;
height:52px;
line-height:52px;
}
.jugas_footer_copyright a {
color:#ffbd2f;
}
/* ######## Custom Widget Css ######################### */
.sidebar .FollowByEmail > h3.title,
.sidebar .FollowByEmail .title-wrap {
margin-bottom: 0
}
.FollowByEmail td {
width: 100%;
float: left;
box-sizing: border-box
}
.FollowByEmail .follow-by-email-inner .follow-by-email-submit {
margin-left: 0;
width: 100%;
border-radius: 0;
height: 30px;
font-size: 11px;
color: #fff;
background-color: #ffbd2f;
font-family: inherit;
text-transform: uppercase;
font-weight: 700;
letter-spacing: 1px
}
.FollowByEmail .follow-by-email-inner .follow-by-email-submit:hover {
opacity:0.8;
}
.FollowByEmail .follow-by-email-inner .follow-by-email-address {
padding-left: 10px;
height: 30px;
border: 1px solid #FFF;
margin-bottom: 5px;
box-sizing: border-box;
font-size: 11px;
font-family: inherit
}
.FollowByEmail .follow-by-email-inner .follow-by-email-address:focus {
border: 1px solid #FFF
}
.FollowByEmail .widget-content {
box-sizing: border-box;
padding: 10px
}
.FollowByEmail .widget-content:before {
content: "Enter your email address to subscribe to this blog and receive notifications of new posts by email.";
font-size: 14px;
color: #f2f2f2;
line-height: 1.4em;
margin-bottom: 5px;
display: block;
padding: 0 2px
}
.item #ads-home {
margin-top: 20px;
}
.cloud-label-widget-content {
display: inline-block;
text-align: left;
}
.cloud-label-widget-content .label-size {
display: inline-block;
float: left;
font-size: 16px;
line-height: normal;
margin: 0 5px 5px 0;
opacity: 1
}
.cloud-label-widget-content .label-size a {
background: #f8f8f8;
color: #878787;
float: left;
font-weight: 400;
line-height: 100%;
margin: 0;
padding: 7px 8px;
text-transform: capitalize;
transition: all .6s;
-webkit-border-radius: 2px;
-moz-border-radius: 2px;
border-radius: 2px;
}
.lowerbar .cloud-label-widget-content .label-size a {
background:#3B3B3B;
}
.cloud-label-widget-content .label-size a:hover,
.cloud-label-widget-content .label-size a:active {
background: #ffbd2f;
color: #fff;
}
.cloud-label-widget-content .label-size .label-count {
background: #ffbd2f;
color: #fff;
white-space: nowrap;
display: inline-block;
padding: 6px 8px;
margin-left: -3px;
line-height: normal;
border-radius: 0 2px 2px 0
}
.label-size-1,
.label-size-2 {
opacity: 100
}
.list-label-widget-content li {
display: block;
padding: 8px 0;
position: relative
}
.list-label-widget-content li a:before {
content: '\203a';
position: absolute;
left: 0px;
top: 8px;
font-size: 22px;
color: #ffbd2f
}
.lowerbar .list-label-widget-content li a {
color:#fff;
}
.list-label-widget-content li a {
color: #0a0a0a;
font-size: 16px;
padding-left: 20px;
font-weight: 400;
text-transform: capitalize;
}
.list-label-widget-content li span:last-child {
color: #ffbd2f;
font-size: 12px;
font-weight: 700;
position: absolute;
top: 9px;
right: 0
}
.PopularPosts .item-thumbnail {
margin: 0 15px 0 0 !important;
width: 90px;
height: 65px;
float: left;
overflow: hidden;
position: relative
}
.PopularPosts .item-thumbnail a {
position: relative;
display: block;
overflow: hidden;
line-height: 0
}
.PopularPosts ul li img {
width: 90px;
height: 65px;
object-fit: cover;
padding: 0;
transition: all .3s ease
}
.PopularPosts .widget-content ul li {
overflow: hidden;
padding: 10px 0;
border-top: 1px solid #f2f2f2
}
.sidebar .PopularPosts .widget-content ul li:first-child,
.sidebar .custom-widget li:first-child,
.tab-widget .PopularPosts .widget-content ul li:first-child,
.tab-widget .custom-widget li:first-child {
padding-top: 0;
border-top: 0
}
.sidebar .PopularPosts .widget-content ul li:last-child,
.sidebar .custom-widget li:last-child,
.tab-widget .PopularPosts .widget-content ul li:last-child,
.tab-widget .custom-widget li:last-child {
padding-bottom: 0
}
.PopularPosts ul li a {
color: #0a0a0a;
font-weight: 400;
font-size: 13px;
line-height: 1.4em;
transition: color .3s;
}
.PopularPosts ul li a:hover {
color: #ffbd2f
}
.PopularPosts .item-title {
margin: 0 0 4px;
padding: 0;
line-height: 0
}
.item-snippet {
display: none;
font-size: 0;
padding-top: 0
}
.PopularPosts ul {
counter-reset: popularcount;
margin: 0;
padding: 0;
}
.PopularPosts .item-thumbnail::before {
background: rgba(0, 0, 0, 0.3);
bottom: 0px;
content: "";
height: 100px;
width: 100px;
left: 0px;
right: 0px;
margin: 0px auto;
position: absolute;
z-index: 3;
}
.BlogArchive ul li {
margin-bottom: 7px !important;
padding-bottom: 7px;
}
.BlogArchive ul li:last-child {
margin-bottom: 0;
padding-bottom: 0;
border-bottom: none;
}
.BlogArchive ul li a {
color:#0a0a0a;
}
.BlogArchive ul li a:hover {
color:#ffbd2f;
}
.BlogArchive .zippy {
color:#e74c3c;
}
.BlogArchive .post-count-link {
font-weight:700;
}
.BlogArchive ul .posts a {
}
.BlogArchive select {
width: 100%;
padding: 10px;
border-color: #777;
}
/* ######## Responsive Css ######################### */
@media only screen and (max-width: 1200px) {
.featured-slider-wrap {
width:auto !important;
}
.sora-author-box-text {
padding: 30px 70px 0 0;
}
.row {
width: 100%;
margin: 0 auto;
float: none;
padding-left: 10px !important;
padding-right: 10px !important;
box-sizing: border-box;
}
}
@media only screen and (max-width: 1100px) {
.sora-author-box-text {
padding: 15px 0 0 0;
}
.sora-author-box img {
margin-right: 40px;
max-width: 400px;
}
div#sora_blogger_cntct_form .wrap-me {
max-width: 500px;
float: none;
clear: both;
margin: 0 auto 20px;
width: 100%;
}
.map-me {
max-width: 500px;
float: none;
clear: both;
margin: 0 auto;
width: 100%;
}
}
@media only screen and (max-width: 980px) {
.item #main-wrapper, .statc_page #main-wrapper, .item #sidebar-wrapper, .statc_page #sidebar-wrapper {
float: none;
clear: both;
width: 100%;
margin: 0 auto;
}
#main-wrapper {
max-width: 100%;
}
#sidebar-wrapper {
padding-top: 20px;
}
#nav1, #nav {
display: none;
}
.menu-wrap {
position: inherit;
}
.item .scroll-head-wrap, .static_page .scroll-head-wrap, .error_page .scroll-head-wrap {
float: left;
margin-left: 10px;
}
.slicknav_menu {
display: block;
}
.item .tm-menu .slicknav_menu, .static_page .tm-menu .slicknav_menu, .error_page .tm-menu .slicknav_menu{
display:block;
top: 20px;
}
.tm-menu, #menu {
height: auto;
}
.item .tm-menu, .static_page .tm-menu, .error_page .tm-menu {
float:none;
display:block;
}
}
@media screen and (max-width: 880px) {
.index .post-grid-item, .archive .post-grid-item {
width: 32%;
}
.home #header-wrapper {
margin-bottom: 10px;
}
.item #content-wrapper {
padding: 0 0 30px;
}
.skills, .skill-details {
width: 100%;
float: none;
padding: 20px;
clear: both;
}
}
@media only screen and (max-width: 768px) {
.sora-author-box img {
margin-right: 0;
max-width: 100%;
float: none;
width: 100%;
height: auto;
clear: both;
}
.sora-author-box-text {
padding: 10px;
text-align: center;
}
.counter-box-item, .works-tiles {
width: 50%;
}
#header h1 {
font-size: 50px;
}
.index .post-grid-item:nth-child(3n), .archive .post-grid-item:nth-child(3n) {
padding-right:15px;
}
.index .post-grid-item:nth-child(2n), .archive .post-grid-item:nth-child(2n) {
padding-right: 0;
}
.index .post-grid-item:nth-child(4n), .archive .post-grid-item:nth-child(4n) {
padding-right: 0;
}
.index .post-grid-item, .archive .post-grid-item {
width: 50%;
}
.tm-menu {
text-align: center;
}
.top-bar-social {
float: none;
width: 100%;
clear: both;
overflow: hidden;
}
.top-bar-social li {
display: inline-block;
float: none;
}
.flickity-prev-next-button {
display:none;
}
.bot-menu, .bottom-bar-social {
float: none;
width: 100%;
clear: both;
overflow: hidden;
position: static;
}
.bot-menu ul {
text-align:center;
}
.bot-menu ul li {
float: none;
}
.bottom-bar-social li {
float: none;
display: inline-block;
}
.related li {
width: 31%;
}
.share-art span {
display: none;
}
.ops-404 {
width: 80%!important;
}
.title-404 {
font-size: 160px!important;
}
#header {
padding: 10px 0px 0;
}
.tysum .ty-feat .tybox-rest {
width:50%;
}
.tysum .ty-feat .tybox-rest:nth-child(2n) {
padding-right: 0;
}
}
@media only screen and (max-width: 767px) {
#header {
padding: 0;
}
#header h1 {
font-size: 30px;
}
.header-text p {
font-size: 30px;
}
.slide-in {
display:none;
}
.search-css .widget-content {
display: none;
}
}
@media only screen and (max-width: 480px) {
.tysum .ty-feat .tybox-rest {
width:100%;
margin-bottom:10px;
clear:both;
float:none;
padding:0;
}
.map-me-full .overlay {
display: none;
}
.comments .comments-content .comment-replies {
margin-left: 0;
}
.index .post-grid-item, .archive .post-grid-item {
width: 100%;
float:none;
}
.search-css .widget-content {
display: block;
}
.slide-in {
display:block;
}
.special-tiles, .works-tiles, .about-tiles, .counter-box-item {
width: 100%;
}
#header h1 {
font-size: 30px;
}
.header-text p {
font-size: 20px;
}
.header-logo-desc span, .header-logo-desc p {
font-size: 16px;
}
.index .post h2,.archive .post h2, .sora-slide .ty-bonos-entry a, #first-post .post h2 {
line-height: 34px;
font-size: 23px;
}
h1.post-title {
font-size: 22px;
margin-bottom: 10px;
}
#sidebar-wrapper {
max-width: 100%;
}
.share-title {
display: none;
}
.share-art {
float: none;
text-align: center;
}
.related li {
width: 100%;
margin:0 auto;
}
.index .post-outer {
padding: 0 0 5x;
}
}
@media only screen and (max-width: 360px) {
.title-404 {
font-size: 150px!important;
}
.header-logo-desc p {
font-size: 100%;
}
#header h1 {
font-size: 250%;
}
}
@media only screen and (max-width: 300px) {
#sidebar-wrapper, .feat-slider-wrap {display:none}
.archive .post h2,.index .post h2, #first-post .post h2 {
line-height: 29px!important;
font-size: 15px!important;
}
article {
overflow: hidden;
}
#blog-pager {
padding: 0;
margin: 0;
}
.index .snippets,.archive .snippets {
display: none;
}
.share-art, .share-box .post-author {
float: none !important;
margin: 0 auto;
text-align: center;
clear: both;
}
.read-more-wrap, .post-labels {
float: none !important;
clear: both;
display: block;
text-align: center;
}
.ops-404 {
font-size: 20px!important;
}
.title-404 {
font-size: 120px!important;
}
h1.post-title {
font-size: 17px;
}
.share-box {
overflow: hidden;
}
.top-bar-social #social a {
width: 24px;
height: 24px;
line-height: 24px;
}
.second-meta .share-art a {
padding: 5px;
}
.comments .avatar-image-container {
display: none;
}
.comments .comment-block {
margin-left: 0 !important;
position: relative;
}
}
-->
</style>
<style>
/*!
* animate.css -http://daneden.me/animate
* Version - 3.5.2
* Licensed under the MIT license - http://opensource.org/licenses/MIT
*
* Copyright (c) 2017 Daniel Eden
*/
.animated{animation-duration:1s;animation-fill-mode:both}.animated.infinite{animation-iteration-count:infinite}.animated.hinge{animation-duration:2s}.animated.bounceIn,.animated.bounceOut,.animated.flipOutX,.animated.flipOutY{animation-duration:.75s}@keyframes bounce{0%,20%,53%,80%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1);transform:translateZ(0)}40%,43%{animation-timing-function:cubic-bezier(.755,.05,.855,.06);transform:translate3d(0,-30px,0)}70%{animation-timing-function:cubic-bezier(.755,.05,.855,.06);transform:translate3d(0,-15px,0)}90%{transform:translate3d(0,-4px,0)}}.bounce{animation-name:bounce;transform-origin:center bottom}@keyframes flash{0%,50%,to{opacity:1}25%,75%{opacity:0}}.flash{animation-name:flash}@keyframes pulse{0%{transform:scaleX(1)}50%{transform:scale3d(1.05,1.05,1.05)}to{transform:scaleX(1)}}.pulse{animation-name:pulse}@keyframes rubberBand{0%{transform:scaleX(1)}30%{transform:scale3d(1.25,.75,1)}40%{transform:scale3d(.75,1.25,1)}50%{transform:scale3d(1.15,.85,1)}65%{transform:scale3d(.95,1.05,1)}75%{transform:scale3d(1.05,.95,1)}to{transform:scaleX(1)}}.rubberBand{animation-name:rubberBand}@keyframes shake{0%,to{transform:translateZ(0)}10%,30%,50%,70%,90%{transform:translate3d(-10px,0,0)}20%,40%,60%,80%{transform:translate3d(10px,0,0)}}.shake{animation-name:shake}@keyframes headShake{0%{transform:translateX(0)}6.5%{transform:translateX(-6px) rotateY(-9deg)}18.5%{transform:translateX(5px) rotateY(7deg)}31.5%{transform:translateX(-3px) rotateY(-5deg)}43.5%{transform:translateX(2px) rotateY(3deg)}50%{transform:translateX(0)}}.headShake{animation-timing-function:ease-in-out;animation-name:headShake}@keyframes swing{20%{transform:rotate(15deg)}40%{transform:rotate(-10deg)}60%{transform:rotate(5deg)}80%{transform:rotate(-5deg)}to{transform:rotate(0deg)}}.swing{transform-origin:top center;animation-name:swing}@keyframes tada{0%{transform:scaleX(1)}10%,20%{transform:scale3d(.9,.9,.9) rotate(-3deg)}30%,50%,70%,90%{transform:scale3d(1.1,1.1,1.1) rotate(3deg)}40%,60%,80%{transform:scale3d(1.1,1.1,1.1) rotate(-3deg)}to{transform:scaleX(1)}}.tada{animation-name:tada}@keyframes wobble{0%{transform:none}15%{transform:translate3d(-25%,0,0) rotate(-5deg)}30%{transform:translate3d(20%,0,0) rotate(3deg)}45%{transform:translate3d(-15%,0,0) rotate(-3deg)}60%{transform:translate3d(10%,0,0) rotate(2deg)}75%{transform:translate3d(-5%,0,0) rotate(-1deg)}to{transform:none}}.wobble{animation-name:wobble}@keyframes jello{0%,11.1%,to{transform:none}22.2%{transform:skewX(-12.5deg) skewY(-12.5deg)}33.3%{transform:skewX(6.25deg) skewY(6.25deg)}44.4%{transform:skewX(-3.125deg) skewY(-3.125deg)}55.5%{transform:skewX(1.5625deg) skewY(1.5625deg)}66.6%{transform:skewX(-.78125deg) skewY(-.78125deg)}77.7%{transform:skewX(.390625deg) skewY(.390625deg)}88.8%{transform:skewX(-.1953125deg) skewY(-.1953125deg)}}.jello{animation-name:jello;transform-origin:center}@keyframes bounceIn{0%,20%,40%,60%,80%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:scale3d(.3,.3,.3)}20%{transform:scale3d(1.1,1.1,1.1)}40%{transform:scale3d(.9,.9,.9)}60%{opacity:1;transform:scale3d(1.03,1.03,1.03)}80%{transform:scale3d(.97,.97,.97)}to{opacity:1;transform:scaleX(1)}}.bounceIn{animation-name:bounceIn}@keyframes bounceInDown{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(0,-3000px,0)}60%{opacity:1;transform:translate3d(0,25px,0)}75%{transform:translate3d(0,-10px,0)}90%{transform:translate3d(0,5px,0)}to{transform:none}}.bounceInDown{animation-name:bounceInDown}@keyframes bounceInLeft{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(-3000px,0,0)}60%{opacity:1;transform:translate3d(25px,0,0)}75%{transform:translate3d(-10px,0,0)}90%{transform:translate3d(5px,0,0)}to{transform:none}}.bounceInLeft{animation-name:bounceInLeft}@keyframes bounceInRight{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(3000px,0,0)}60%{opacity:1;transform:translate3d(-25px,0,0)}75%{transform:translate3d(10px,0,0)}90%{transform:translate3d(-5px,0,0)}to{transform:none}}.bounceInRight{animation-name:bounceInRight}@keyframes bounceInUp{0%,60%,75%,90%,to{animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;transform:translate3d(0,3000px,0)}60%{opacity:1;transform:translate3d(0,-20px,0)}75%{transform:translate3d(0,10px,0)}90%{transform:translate3d(0,-5px,0)}to{transform:translateZ(0)}}.bounceInUp{animation-name:bounceInUp}@keyframes bounceOut{20%{transform:scale3d(.9,.9,.9)}50%,55%{opacity:1;transform:scale3d(1.1,1.1,1.1)}to{opacity:0;transform:scale3d(.3,.3,.3)}}.bounceOut{animation-name:bounceOut}@keyframes bounceOutDown{20%{transform:translate3d(0,10px,0)}40%,45%{opacity:1;transform:translate3d(0,-20px,0)}to{opacity:0;transform:translate3d(0,2000px,0)}}.bounceOutDown{animation-name:bounceOutDown}@keyframes bounceOutLeft{20%{opacity:1;transform:translate3d(20px,0,0)}to{opacity:0;transform:translate3d(-2000px,0,0)}}.bounceOutLeft{animation-name:bounceOutLeft}@keyframes bounceOutRight{20%{opacity:1;transform:translate3d(-20px,0,0)}to{opacity:0;transform:translate3d(2000px,0,0)}}.bounceOutRight{animation-name:bounceOutRight}@keyframes bounceOutUp{20%{transform:translate3d(0,-10px,0)}40%,45%{opacity:1;transform:translate3d(0,20px,0)}to{opacity:0;transform:translate3d(0,-2000px,0)}}.bounceOutUp{animation-name:bounceOutUp}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fadeIn{animation-name:fadeIn}@keyframes fadeInDown{0%{opacity:0;transform:translate3d(0,-100%,0)}to{opacity:1;transform:none}}.fadeInDown{animation-name:fadeInDown}@keyframes fadeInDownBig{0%{opacity:0;transform:translate3d(0,-2000px,0)}to{opacity:1;transform:none}}.fadeInDownBig{animation-name:fadeInDownBig}@keyframes fadeInLeft{0%{opacity:0;transform:translate3d(-100%,0,0)}to{opacity:1;transform:none}}.fadeInLeft{animation-name:fadeInLeft}@keyframes fadeInLeftBig{0%{opacity:0;transform:translate3d(-2000px,0,0)}to{opacity:1;transform:none}}.fadeInLeftBig{animation-name:fadeInLeftBig}@keyframes fadeInRight{0%{opacity:0;transform:translate3d(100%,0,0)}to{opacity:1;transform:none}}.fadeInRight{animation-name:fadeInRight}@keyframes fadeInRightBig{0%{opacity:0;transform:translate3d(2000px,0,0)}to{opacity:1;transform:none}}.fadeInRightBig{animation-name:fadeInRightBig}@keyframes fadeInUp{0%{opacity:0;transform:translate3d(0,100%,0)}to{opacity:1;transform:none}}.fadeInUp{animation-name:fadeInUp}@keyframes fadeInUpBig{0%{opacity:0;transform:translate3d(0,2000px,0)}to{opacity:1;transform:none}}.fadeInUpBig{animation-name:fadeInUpBig}@keyframes fadeOut{0%{opacity:1}to{opacity:0}}.fadeOut{animation-name:fadeOut}@keyframes fadeOutDown{0%{opacity:1}to{opacity:0;transform:translate3d(0,100%,0)}}.fadeOutDown{animation-name:fadeOutDown}@keyframes fadeOutDownBig{0%{opacity:1}to{opacity:0;transform:translate3d(0,2000px,0)}}.fadeOutDownBig{animation-name:fadeOutDownBig}@keyframes fadeOutLeft{0%{opacity:1}to{opacity:0;transform:translate3d(-100%,0,0)}}.fadeOutLeft{animation-name:fadeOutLeft}@keyframes fadeOutLeftBig{0%{opacity:1}to{opacity:0;transform:translate3d(-2000px,0,0)}}.fadeOutLeftBig{animation-name:fadeOutLeftBig}@keyframes fadeOutRight{0%{opacity:1}to{opacity:0;transform:translate3d(100%,0,0)}}.fadeOutRight{animation-name:fadeOutRight}@keyframes fadeOutRightBig{0%{opacity:1}to{opacity:0;transform:translate3d(2000px,0,0)}}.fadeOutRightBig{animation-name:fadeOutRightBig}@keyframes fadeOutUp{0%{opacity:1}to{opacity:0;transform:translate3d(0,-100%,0)}}.fadeOutUp{animation-name:fadeOutUp}@keyframes fadeOutUpBig{0%{opacity:1}to{opacity:0;transform:translate3d(0,-2000px,0)}}.fadeOutUpBig{animation-name:fadeOutUpBig}@keyframes flip{0%{transform:perspective(400px) rotateY(-1turn);animation-timing-function:ease-out}40%{transform:perspective(400px) translateZ(150px) rotateY(-190deg);animation-timing-function:ease-out}50%{transform:perspective(400px) translateZ(150px) rotateY(-170deg);animation-timing-function:ease-in}80%{transform:perspective(400px) scale3d(.95,.95,.95);animation-timing-function:ease-in}to{transform:perspective(400px);animation-timing-function:ease-in}}.animated.flip{-webkit-backface-visibility:visible;backface-visibility:visible;animation-name:flip}@keyframes flipInX{0%{transform:perspective(400px) rotateX(90deg);animation-timing-function:ease-in;opacity:0}40%{transform:perspective(400px) rotateX(-20deg);animation-timing-function:ease-in}60%{transform:perspective(400px) rotateX(10deg);opacity:1}80%{transform:perspective(400px) rotateX(-5deg)}to{transform:perspective(400px)}}.flipInX{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipInX}@keyframes flipInY{0%{transform:perspective(400px) rotateY(90deg);animation-timing-function:ease-in;opacity:0}40%{transform:perspective(400px) rotateY(-20deg);animation-timing-function:ease-in}60%{transform:perspective(400px) rotateY(10deg);opacity:1}80%{transform:perspective(400px) rotateY(-5deg)}to{transform:perspective(400px)}}.flipInY{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipInY}@keyframes flipOutX{0%{transform:perspective(400px)}30%{transform:perspective(400px) rotateX(-20deg);opacity:1}to{transform:perspective(400px) rotateX(90deg);opacity:0}}.flipOutX{animation-name:flipOutX;-webkit-backface-visibility:visible!important;backface-visibility:visible!important}@keyframes flipOutY{0%{transform:perspective(400px)}30%{transform:perspective(400px) rotateY(-15deg);opacity:1}to{transform:perspective(400px) rotateY(90deg);opacity:0}}.flipOutY{-webkit-backface-visibility:visible!important;backface-visibility:visible!important;animation-name:flipOutY}@keyframes lightSpeedIn{0%{transform:translate3d(100%,0,0) skewX(-30deg);opacity:0}60%{transform:skewX(20deg);opacity:1}80%{transform:skewX(-5deg);opacity:1}to{transform:none;opacity:1}}.lightSpeedIn{animation-name:lightSpeedIn;animation-timing-function:ease-out}@keyframes lightSpeedOut{0%{opacity:1}to{transform:translate3d(100%,0,0) skewX(30deg);opacity:0}}.lightSpeedOut{animation-name:lightSpeedOut;animation-timing-function:ease-in}@keyframes rotateIn{0%{transform-origin:center;transform:rotate(-200deg);opacity:0}to{transform-origin:center;transform:none;opacity:1}}.rotateIn{animation-name:rotateIn}@keyframes rotateInDownLeft{0%{transform-origin:left bottom;transform:rotate(-45deg);opacity:0}to{transform-origin:left bottom;transform:none;opacity:1}}.rotateInDownLeft{animation-name:rotateInDownLeft}@keyframes rotateInDownRight{0%{transform-origin:right bottom;transform:rotate(45deg);opacity:0}to{transform-origin:right bottom;transform:none;opacity:1}}.rotateInDownRight{animation-name:rotateInDownRight}@keyframes rotateInUpLeft{0%{transform-origin:left bottom;transform:rotate(45deg);opacity:0}to{transform-origin:left bottom;transform:none;opacity:1}}.rotateInUpLeft{animation-name:rotateInUpLeft}@keyframes rotateInUpRight{0%{transform-origin:right bottom;transform:rotate(-90deg);opacity:0}to{transform-origin:right bottom;transform:none;opacity:1}}.rotateInUpRight{animation-name:rotateInUpRight}@keyframes rotateOut{0%{transform-origin:center;opacity:1}to{transform-origin:center;transform:rotate(200deg);opacity:0}}.rotateOut{animation-name:rotateOut}@keyframes rotateOutDownLeft{0%{transform-origin:left bottom;opacity:1}to{transform-origin:left bottom;transform:rotate(45deg);opacity:0}}.rotateOutDownLeft{animation-name:rotateOutDownLeft}@keyframes rotateOutDownRight{0%{transform-origin:right bottom;opacity:1}to{transform-origin:right bottom;transform:rotate(-45deg);opacity:0}}.rotateOutDownRight{animation-name:rotateOutDownRight}@keyframes rotateOutUpLeft{0%{transform-origin:left bottom;opacity:1}to{transform-origin:left bottom;transform:rotate(-45deg);opacity:0}}.rotateOutUpLeft{animation-name:rotateOutUpLeft}@keyframes rotateOutUpRight{0%{transform-origin:right bottom;opacity:1}to{transform-origin:right bottom;transform:rotate(90deg);opacity:0}}.rotateOutUpRight{animation-name:rotateOutUpRight}@keyframes hinge{0%{transform-origin:top left;animation-timing-function:ease-in-out}20%,60%{transform:rotate(80deg);transform-origin:top left;animation-timing-function:ease-in-out}40%,80%{transform:rotate(60deg);transform-origin:top left;animation-timing-function:ease-in-out;opacity:1}to{transform:translate3d(0,700px,0);opacity:0}}.hinge{animation-name:hinge}@keyframes jackInTheBox{0%{opacity:0;transform:scale(.1) rotate(30deg);transform-origin:center bottom}50%{transform:rotate(-10deg)}70%{transform:rotate(3deg)}to{opacity:1;transform:scale(1)}}.jackInTheBox{animation-name:jackInTheBox}@keyframes rollIn{0%{opacity:0;transform:translate3d(-100%,0,0) rotate(-120deg)}to{opacity:1;transform:none}}.rollIn{animation-name:rollIn}@keyframes rollOut{0%{opacity:1}to{opacity:0;transform:translate3d(100%,0,0) rotate(120deg)}}.rollOut{animation-name:rollOut}@keyframes zoomIn{0%{opacity:0;transform:scale3d(.3,.3,.3)}50%{opacity:1}}.zoomIn{animation-name:zoomIn}@keyframes zoomInDown{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,-1000px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,60px,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInDown{animation-name:zoomInDown}@keyframes zoomInLeft{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(-1000px,0,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(10px,0,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInLeft{animation-name:zoomInLeft}@keyframes zoomInRight{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(1000px,0,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(-10px,0,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInRight{animation-name:zoomInRight}@keyframes zoomInUp{0%{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,1000px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}60%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,-60px,0);animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomInUp{animation-name:zoomInUp}@keyframes zoomOut{0%{opacity:1}50%{opacity:0;transform:scale3d(.3,.3,.3)}to{opacity:0}}.zoomOut{animation-name:zoomOut}@keyframes zoomOutDown{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,-60px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}to{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,2000px,0);transform-origin:center bottom;animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomOutDown{animation-name:zoomOutDown}@keyframes zoomOutLeft{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(42px,0,0)}to{opacity:0;transform:scale(.1) translate3d(-2000px,0,0);transform-origin:left center}}.zoomOutLeft{animation-name:zoomOutLeft}@keyframes zoomOutRight{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(-42px,0,0)}to{opacity:0;transform:scale(.1) translate3d(2000px,0,0);transform-origin:right center}}.zoomOutRight{animation-name:zoomOutRight}@keyframes zoomOutUp{40%{opacity:1;transform:scale3d(.475,.475,.475) translate3d(0,60px,0);animation-timing-function:cubic-bezier(.55,.055,.675,.19)}to{opacity:0;transform:scale3d(.1,.1,.1) translate3d(0,-2000px,0);transform-origin:center bottom;animation-timing-function:cubic-bezier(.175,.885,.32,1)}}.zoomOutUp{animation-name:zoomOutUp}@keyframes slideInDown{0%{transform:translate3d(0,-100%,0);visibility:visible}to{transform:translateZ(0)}}.slideInDown{animation-name:slideInDown}@keyframes slideInLeft{0%{transform:translate3d(-100%,0,0);visibility:visible}to{transform:translateZ(0)}}.slideInLeft{animation-name:slideInLeft}@keyframes slideInRight{0%{transform:translate3d(100%,0,0);visibility:visible}to{transform:translateZ(0)}}.slideInRight{animation-name:slideInRight}@keyframes slideInUp{0%{transform:translate3d(0,100%,0);visibility:visible}to{transform:translateZ(0)}}.slideInUp{animation-name:slideInUp}@keyframes slideOutDown{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(0,100%,0)}}.slideOutDown{animation-name:slideOutDown}@keyframes slideOutLeft{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(-100%,0,0)}}.slideOutLeft{animation-name:slideOutLeft}@keyframes slideOutRight{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(100%,0,0)}}.slideOutRight{animation-name:slideOutRight}@keyframes slideOutUp{0%{transform:translateZ(0)}to{visibility:hidden;transform:translate3d(0,-100%,0)}}.slideOutUp{animation-name:slideOutUp}
</style>
<style>
/*-------Typography and ShortCodes-------*/
.firstcharacter{float:left;color:#27ae60;font-size:75px;line-height:60px;padding-top:4px;padding-right:8px;padding-left:3px}.post-body h1,.post-body h2,.post-body h3,.post-body h4,.post-body h5,.post-body h6{margin-bottom:15px;color:#2c3e50}blockquote{font-style:italic;color:#888;border-left:5px solid #27ae60;margin-left:0;padding:10px 15px}blockquote:before{content:'\f10d';display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;margin-right:10px;color:#888}blockquote:after{content:'\f10e';display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;margin-left:10px;color:#888}.button{background-color:#2c3e50;float:left;padding:5px 12px;margin:5px;color:#fff;text-align:center;border:0;cursor:pointer;border-radius:3px;display:block;text-decoration:none;font-weight:400;transition:all .3s ease-out !important;-webkit-transition:all .3s ease-out !important}a.button{color:#fff}.button:hover{background-color:#27ae60;color:#fff}.button.small{font-size:12px;padding:5px 12px}.button.medium{font-size:16px;padding:6px 15px}.button.large{font-size:18px;padding:8px 18px}.small-button{width:100%;overflow:hidden;clear:both}.medium-button{width:100%;overflow:hidden;clear:both}.large-button{width:100%;overflow:hidden;clear:both}.demo:before{content:"\f06e";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.download:before{content:"\f019";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.buy:before{content:"\f09d";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.visit:before{content:"\f14c";margin-right:5px;display:inline-block;font-family:FontAwesome;font-style:normal;font-weight:400;line-height:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.widget .post-body ul,.widget .post-body ol{line-height:1.5;font-weight:400}.widget .post-body li{margin:5px 0;padding:0;line-height:1.5}.post-body ul li:before{content:"\f105";margin-right:5px;font-family:fontawesome}pre{font-family:Monaco, "Andale Mono", "Courier New", Courier, monospace;background-color:#2c3e50;background-image:-webkit-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:-moz-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:-ms-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:-o-linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);background-image:linear-gradient(rgba(0, 0, 0, 0.05) 50%, transparent 50%, transparent);-webkit-background-size:100% 50px;-moz-background-size:100% 50px;background-size:100% 50px;line-height:25px;color:#f1f1f1;position:relative;padding:0 7px;margin:15px 0 10px;overflow:hidden;word-wrap:normal;white-space:pre;position:relative}pre:before{content:'Code';display:block;background:#F7F7F7;margin-left:-7px;margin-right:-7px;color:#2c3e50;padding-left:7px;font-weight:400;font-size:14px}pre code,pre .line-number{display:block}pre .line-number a{color:#27ae60;opacity:0.6}pre .line-number span{display:block;float:left;clear:both;width:20px;text-align:center;margin-left:-7px;margin-right:7px}pre .line-number span:nth-child(odd){background-color:rgba(0, 0, 0, 0.11)}pre .line-number span:nth-child(even){background-color:rgba(255, 255, 255, 0.05)}pre .cl{display:block;clear:both}#contact{background-color:#fff;margin:30px 0 !important}#contact .contact-form-widget{max-width:100% !important}#contact .contact-form-name,#contact .contact-form-email,#contact .contact-form-email-message{background-color:#FFF;border:1px solid #eee;border-radius:3px;padding:10px;margin-bottom:10px !important;max-width:100% !important}#contact .contact-form-name{width:47.7%;height:50px}#contact .contact-form-email{width:49.7%;height:50px}#contact .contact-form-email-message{height:150px}#contact .contact-form-button-submit{max-width:100%;width:100%;z-index:0;margin:4px 0 0;padding:10px !important;text-align:center;cursor:pointer;background:#27ae60;border:0;height:auto;-webkit-border-radius:2px;-moz-border-radius:2px;-ms-border-radius:2px;-o-border-radius:2px;border-radius:2px;text-transform:uppercase;-webkit-transition:all .2s ease-out;-moz-transition:all .2s ease-out;-o-transition:all .2s ease-out;-ms-transition:all .2s ease-out;transition:all .2s ease-out;color:#FFF}#contact .contact-form-button-submit:hover{background:#2c3e50}#contact .contact-form-email:focus,#contact .contact-form-name:focus,#contact .contact-form-email-message:focus{box-shadow:none !important}.alert-message{position:relative;display:block;background-color:#FAFAFA;padding:20px;margin:20px 0;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;color:#2f3239;border:1px solid}.alert-message p{margin:0 !important;padding:0;line-height:22px;font-size:13px;color:#2f3239}.alert-message span{font-size:14px !important}.alert-message i{font-size:16px;line-height:20px}.alert-message.success{background-color:#f1f9f7;border-color:#e0f1e9;color:#1d9d74}.alert-message.success a,.alert-message.success span{color:#1d9d74}.alert-message.alert{background-color:#DAEFFF;border-color:#8ED2FF;color:#378FFF}.alert-message.alert a,.alert-message.alert span{color:#378FFF}.alert-message.warning{background-color:#fcf8e3;border-color:#faebcc;color:#8a6d3b}.alert-message.warning a,.alert-message.warning span{color:#8a6d3b}.alert-message.error{background-color:#FFD7D2;border-color:#FF9494;color:#F55D5D}.alert-message.error a,.alert-message.error span{color:#F55D5D}.fa-check-circle:before{content:"\f058"}.fa-info-circle:before{content:"\f05a"}.fa-exclamation-triangle:before{content:"\f071"}.fa-exclamation-circle:before{content:"\f06a"}.post-table table{border-collapse:collapse;width:100%}.post-table th{background-color:#eee;font-weight:bold}.post-table th,.post-table td{border:0.125em solid #333;line-height:1.5;padding:0.75em;text-align:left}@media (max-width: 30em){.post-table thead tr{position:absolute;top:-9999em;left:-9999em}.post-table tr{border:0.125em solid #333;border-bottom:0}.post-table tr + tr{margin-top:1.5em}.post-table tr,.post-table td{display:block}.post-table td{border:none;border-bottom:0.125em solid #333;padding-left:50%}.post-table td:before{content:attr(data-label);display:inline-block;font-weight:bold;line-height:1.5;margin-left:-100%;width:100%}}@media (max-width: 20em){.post-table td{padding-left:0.75em}.post-table td:before{display:block;margin-bottom:0.75em;margin-left:0}}
.FollowByEmail {
clear: both;
}
</style>
<style id="template-skin-1" type="text/css">
<!--
/*------Layout (No Edit)----------*/
#layout #preloader, #layout .scrolling-menu {
display: none;
}
#layout .sora-contact-widget {
display:none;
}
body#layout #outer-wrapper {
padding: 0;
width: 800px
}
body#layout .section h4 {
color: #333!important;
text-align:center;
text-transform:uppercase;
letter-spacing:1.5px;
}
body#layout .tm-menu, body#layout #menu {
height: auto;
position:static;
}
body#layout #menu .widget {
display: block;
visibility:visible;
}
body#layout #header-wrapper {
height: auto;
}
body#layout #content-wrapper {
margin: 0 auto;
padding:0;
}
body#layout #main-wrapper {
float: left;
width: 70%;
margin: 0;
padding: 0
}
body#layout #sidebar-wrapper {
float: right;
width: 30%;
margin: 0;
padding: 0;
display: block;
visibility: visible;
height: auto;
opacity: 1;
}
body#layout #sidebar-wrapper .section {
background-color: #f8e244 !important;
border: 1px solid #fff
}
body#layout #sidebar-wrapper .section h4 {
color:#fff;
}
body#layout #sidebar-wrapper .section .widget-content {
border-color: #5a7ea2!important
}
body#layout #sidebar-wrapper .section .draggable-widget .widget-wrap2 {
background-color: #0080ce !important
}
body#layout #main-wrapper #main {
margin-right: 4px;
background-color: #5a7ea2;
border-color: #34495e
}
body#layout #main-wrapper #main h4 {
color: #fff!important
}
body#layout .layout-widget-description {
display: none!important
}
body#layout #Blog1 .widget-content {
border-color: #34495e
}
body#layout .draggable-widget .widget-wrap2 {
background: #0080ce url(https://www.blogger.com/img/widgets/draggable.png) no-repeat 4px 50%;
}
body#layout .editlink {
background: #0080ce;
color: #fff !important;
padding: 0 3px;
line-height: 18px;
border: 1px solid #2469d9;
border-radius: 3px;
text-transform: uppercase;
letter-spacing: 1px;
text-decoration: none !important;
}
body#layout .add_widget {
background: #fff;
}
body#layout .tm-menu .section {
background-color: #f6b3d2 !important;
border: 1px solid #ed67a7
}
body#layout .header {
background-color: #f2132d !important;
border: 1px solid #f53551
}
body#layout .feat-slider-wrap .section {
background-color: #a0d3db !important;
border: 1px solid #a2dbeb
}
body#layout .insta-wrap .section {
background-color: #a0d3db !important;
border: 1px solid #a2dbeb
}
body#layout .FollowByEmail .widget-content:before, body#layout .jugas_footer_copyright {
display:none;
}
body#layout .sora-special-box, body#layout .sora-works-box, body#layout .sora-about-box, body#layout .insta-wrap, body#layout .Portfolio-title {display:none;}
/*------Layout (end)----------*/
-->
</style>
<script type="text/javascript"> //<![CDATA[
var no_image = "http://3.bp.blogspot.com/-Yw8BIuvwoSQ/VsjkCIMoltI/AAAAAAAAC4c/s55PW6xEKn0/s1600-r/nth.png";
var month_format = [, "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];
var more_text = "View More";
var comments_text = "<span>Post </span>Comment";
var pagenav_prev = "Previous";
var pagenav_next = "Next";
//]]>
</script>
<link href="./Sora%20Home_files/authorization.css" media="all" onload="if(media!='all')media='all'" rel="stylesheet">
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/common.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/util.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/map.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/marker.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<style type="text/css">
.gm-style {
font: 400 11px Roboto, Arial, sans-serif;
text-decoration: none;
}
.gm-style img { max-width: none; }
.style3 {font-size: 180%}
.style4 {
font-size: 30px;
color: #FFFFFF;
font-family: "Times New Roman", Times, serif;
}
.style5 {
font-size: 25px;
color: #000000;
}
</style>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/onion.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/ViewportInfoService.GetViewportInfo"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/vt"></script>
<link type="text/css" rel="stylesheet" charset="UTF-8" href="./Sora%20Home_files/translateelement.css">
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/controls.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/AuthenticationService.Authenticate"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/QuotaService.RecordEvent"></script>
<script type="text/javascript" charset="UTF-8" src="./Sora%20Home_files/stats.js.t%E1%BA%A3i+xu%E1%BB%91ng"></script>
<style>
article {
padding: 0 10px 10px;
box-sizing: border-box;
clear: both;
}
.post-header {
padding:0;
}
@media only screen and (max-width: 768px) {
article {
padding:10px;
}
}
</style>
<noscript>&lt;link
href='https://www.blogger.com/dyn-css/authorization.css?targetBlogID=3971811510442427732&amp;amp;zx=b0524df0-6767-4601-91a9-bafdd68fd717'
rel='stylesheet'/&gt;</noscript></head>

<noscript>&lt;link
href='https://www.blogger.com/dyn-css/authorization.css?targetBlogID=3971811510442427732&amp;amp;zx=b0524df0-6767-4601-91a9-bafdd68fd717'
rel='stylesheet'/&gt;</noscript>

<body class="index" style="">
<!--preloader start-->
<div id="preloader" style="display: none;">
<div class="box">
<div class="loader7" style="display: none;"></div>
</div>
</div>
<!--preloader end-->
<div id="outer-wrapper" class="index home">
<div class="scroll-header" id="head-trigger">
<div class="scroll-head-wrap">
<div style="clear: both;"></div>
</div>
</div>
<div id="header-wrapper">
<div class="fenix-head">
<div class="fenix-sub-head row">
<div class="home-head-view">
<div class="scrollin-logo">
<div class="header section" id="header" name="Logo &amp; Title">
<div class="widget Header" data-version="1" id="Header1">
<div id="header-inner"><img alt="Sora Home" id="Header1_headerimg" src="img/212.png" style="display: block;" height="300" width="300">
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript"> //<![CDATA[
$( ".scrollin-logo" ).appendTo( $( ".home-head-view" ) );
//]]>
</script>
<div style="clear: both;"></div>
<div class="header-text search-css">
<div class="logo-text section" id="Header Title" name="Header Title Widget">
<div class="widget HTML" data-version="1" id="HTML30">
<div class="widget-content">
<p class="search-note"><span class="itatu style3">Thư
Viện Trường Đại Học Trà Vinh</span>
</p>
</div>
<div class="feat-search-wrapper">
<div class="feat-search-form">
<form _lpchecked="1" action="dangnhap.php" class="search-form" id="searchform" method="post"><button class="sbutton" id="search-image" style="border: 0pt none ; vertical-align: top;"> <span class="style5">Đăng Nhập</span></button>
</form>
</div>
</div>
<div class="jugas_footer_copyright"> Created By Nhóm Sinh
Viên NCKH Trường DHTV
</div>
<div class="bottom-bar-social blue section" id="Footer social widget" name="Footer Social Widget">
<div class="widget LinkList" data-version="1" id="LinkList236">
<div class="widget-content"></div>
</div>
</div>
</div>
</div>
</div>
</div></div></div></div></body></html>