<?php
echo "<table width=\"998\" border=\"1\" align=\"center\">\n"; 
echo "  <tr>\n"; 
echo "    <td colspan=\"5\"><h3 align=\"left\" class=\"style7\">Thư viện Trường Đại học Trà Vinh. </h3>\n"; 
echo "        <h3 align=\"left\"><span class=\"style7\">Số 126 - Nguyễn Thiện Thành, Khóm 4, phường 5, Thành phố Trà Vinh - Tỉnh Trà Vinh.</span><br />\n"; 
echo "      </h3></td>\n"; 
echo "    <td width=\"500\"><img src=\"img/002.jpg\" width=\"500\" height=\"193\" /></td>\n"; 
echo "  </tr>\n"; 
echo "</table>\n";
?>