<?php
include('admin.php');
?>

<?php
include('connect.php');
	$sql1 = "SELECT * FROM thongtin";
	$result1 = mysqli_query($conn, $sql1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0030)http://avada-mbl.blogspot.com/ -->
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xmlns:b="http://www.google.com/2005/gml/b" xmlns:data="http://www.google.com/2005/gml/data" xmlns:expr="http://www.google.com/2005/gml/expr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/3957297643-widget_css_bundle.css" rel="stylesheet" type="text/css">
<link href="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/css" rel="stylesheet" type="text/css">

<meta content="blogger" name="generator">
<link href="http://avada-mbl.blogspot.com/favicon.ico" rel="icon" type="image/x-icon">
<link href="http://avada-mbl.blogspot.com/" rel="canonical">
<link rel="alternate" type="application/atom+xml" title="MBL Avada - Atom" href="http://avada-mbl.blogspot.com/feeds/posts/default">
<link rel="alternate" type="application/rss+xml" title="MBL Avada - RSS" href="http://avada-mbl.blogspot.com/feeds/posts/default?alt=rss">
<link rel="service.post" type="application/atom+xml" title="MBL Avada - Atom" href="https://www.blogger.com/feeds/6803739683768993764/posts/default">
<link rel="openid.server" href="https://www.blogger.com/openid-server.g">
<link rel="openid.delegate" href="http://avada-mbl.blogspot.com/">
<!--Can't find substitution for tag [blog.ieCssRetrofitLinks]-->
<meta content="http://avada-mbl.blogspot.com/" property="og:url">
<meta content="MBL Avada" property="og:title">
<meta content="" property="og:description">
<!--[if IE]> <script> (function() { var html5 = ("abbr,article,aside,audio,canvas,datalist,details," + "figure,footer,header,hgroup,mark,menu,meter,nav,output," + "progress,section,time,video").split(','); for (var i = 0; i < html5.length; i++) { document.createElement(html5[i]); } try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {} })(); </script> <![endif]-->
<title>Thư Viện DHTV</title>
<meta content="Description-Here " name="description">
<meta content="Keyword-Here" name="keywords">
<meta content="ALL" name="ROBOTS">
<style id="page-skin-1" type="text/css">
<!--

@font-face {
  font-family: 'VNI-Aztek';
  src: url('VNI-Aztek.eot?#iefix') format('embedded-opentype'),  url('VNI-Aztek.woff') format('woff'), url('VNI-Aztek.ttf')  format('truetype'), url('VNI-Aztek.svg#VNI-Aztek') format('svg');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'VNI-Bandit';
  src: url('VNI-Bandit.eot?#iefix') format('embedded-opentype'),  url('VNI-Bandit.woff') format('woff'), url('VNI-Bandit.ttf')  format('truetype'), url('VNI-Bandit.svg#VNI-Bandit') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'VNI-AlgerianU';
  src: url('VNI-AlgerianU.eot?#iefix') format('embedded-opentype'),  url('VNI-AlgerianU.woff') format('woff'), url('VNI-AlgerianU.ttf')  format('truetype'), url('VNI-AlgerianU.svg#VNI-AlgerianU') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'VNI-Colonna';
  src: url('VNI-Colonna.eot?#iefix') format('embedded-opentype'),  url('VNI-Colonna.woff') format('woff'), url('VNI-Colonna.ttf')  format('truetype'), url('VNI-Colonna.svg#VNI-Colonna') format('svg');
  font-weight: normal;
  font-style: normal;
}
@font-face {
  font-family: 'VNI-Lithos';
  src: url('VNI-Lithos.eot?#iefix') format('embedded-opentype'),  url('VNI-Lithos.woff') format('woff'), url('VNI-Lithos.ttf')  format('truetype'), url('VNI-Lithos.svg#VNI-Lithos') format('svg');
  font-weight: normal;
  font-style: normal;
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
.abc{opacity: 0.8;
    filter: alpha(opacity=80); /* For IE8 and earlier */}
.a:hover:not(.active) {
	opacity: 0.5;
    filter: alpha(opacity=50); /* For IE8 and earlier */}
/*
-----------------------------------------------
Blogger Template Style
Name:   MBL Avada
Designer: Syed Faizan Ali
URL:  http://www.templateism.com/
Date:   31 December 2012
License:  This free Blogger template is licensed under the Creative Commons Attribution 3.0 License, which permits both personal and commercial use.
However, to satisfy the 'attribution' clause of the license, you are required to keep the footer links intact which provides due credit to its authors. For more specific details about the license, you may visit the URL below:
http://creativecommons.org/licenses/by/3.0/
----------------------------------------------- */
body#layout ul{list-style-type:none;list-style:none} body#layout ul li{list-style-type:none;list-style:none} body { color: #333; font-family:Open Sans, Helvetica Neue,Arial,Helvetica, sans-serif; font-size:12px; } a { text-decoration:none; color:#333; } a:hover { color:#a0ce4e; text-decoration:none; } #body-wrapper{margin:0px;padding:0px;}
body{ background: url(http://4.bp.blogspot.com/-w19VBzwqFxE/UMUxWLm_bYI/AAAAAAAAJUQ/xv9AOlPPTc4/s1600/bg.png)}
/* Header-----------------------------------------------*/
#header-wrapper {float: left; height: 88px; width: 100%; } .headerleft { width: 400px; height:88px; margin-top:-20px; margin-left:5px; float: left; font-family: Georgia; font-size: 12px; font-family: 'BreeSerifRegular', Arial, sans-serif; color: #fff; } .headerleft a img { border: none; margin-top: 35px; } #header-wrapper2 { margin-left: 450px;width:500px;} #header-inner{ float:left; overflow:hidden; margin:31px 0 0; } #header-inner a{ height:100%; display:block; } #wrap1 { background-color: #fff; border: 2px solid #ddd; margin: -40px auto 0; margin-top:-12px; width: 960px; height:100%; }
/* Outer-Wrapper----------------------------------------------- */
#outer-wrapper{width:960px;margin:0px auto 0px;padding:0px;text-align:left;background:#FFFFFF;} #content-wrapper{margin-top:-35px;} #main-wrapper{width:615px;float:left;margin:0px;padding:0px 0px 0px 0px;word-wrap:break-word;overflow:hidden;text-shadow:0 1px 0 #fff;} #main-wrapper2{width:615px;float:left;margin:0px;padding:0px 0px 0px 0px;word-wrap:break-word;overflow:hidden;text-shadow:0 1px 0 #fff;} #rsidebar-wrapper{width:290px;float:right;margin:0px;padding:0px 0px 0px 0px;word-wrap:break-word;overflow:hidden;text-shadow:0 1px 0 #fff;}
/* Headings----------------------------------------------- */
h2{}
/* Posts-----------------------------------------------*/
h2.date-header{margin:1.5em 0 .5em;display:none;} .wrapfullpost{} .post{margin-bottom:15px; margin-left:10px;} .post-title a { color: #494949; } .post-title a:hover { color: #222; } .post-body{ color: #333; font: 14px/25px Open Sans, Helvetica Neue,Arial,Helvetica, sans-serif; } .post-footer{margin:5px 0;} .comment-link{margin-$startSide:.6em} .postmeta-primary{color:#999;font-size:12px;line-height:18px;padding:0 0 5px 0} .postmeta-secondary{color:#999;font-size:12px;line-height:18px;padding:0 0 10px 0} .postmeta-primary span,.postmeta-secondary span{padding:3px 0 3px 20px;background-position:left center;background-repeat:no-repeat} .meta_date{background-image:url(http://2.bp.blogspot.com/-paWPYJvQDqA/UC7eiuIKgUI/AAAAAAAAAvw/af410sUcO2w/s000/date.png)} .meta_author{background-image:url(http://3.bp.blogspot.com/-reTaoyVmDXA/UC7ejgVBQbI/AAAAAAAAAv4/u6d-iPeLZi0/s000/author.png)} .meta_comments{background-image:url(http://2.bp.blogspot.com/-zZgvwATiF3E/UC7ej-cvmbI/AAAAAAAAAwA/THMs0579MII/s000/comments.png)} .meta_edit{background-image:url(file:///C|/Users/TrongHao/Desktop/images/edit.png)} .meta_categories{background-image:url(http://1.bp.blogspot.com/-g-ptS39XbNM/UC7ekTJsEXI/AAAAAAAAAwI/t8fMhUuUvQI/s000/category.png)} .meta_tags{background-image:url(http://3.bp.blogspot.com/-fZuK3yymXmo/UC7ek6kEDLI/AAAAAAAAAwQ/-J16r4bHvFo/s000/tags.png)} /* Sidebar
Content----------------------------------------------- */
.sidebar{margin:0 0 10px 0;font-size:13px;color:#374142;} .sidebar a{text-decoration:none;color:#374142;} .sidebar a:hover{text-decoration:none;color:#a0ce4e;} .sidebar h2{font-size: 19px; text-transform: none!important; margin-bottom: 12px; text-transform: uppercase; font-weight: normal; font-family: 'BreeSerifRegular', Arial, sans-serif;} .sidebar ul{list-style-type:none;list-style:none;margin:0px;padding:0px;} .sidebar ul li{padding:0 0 9px 0;margin:0 0 8px 0;} .sidebar .widget{margin:0 0 15px 0;padding:0;color:#374142;font-size:13px;} .main .widget{margin:0 0 5px;padding:0 0 2px} .main .Blog{border-bottom-width:0}
/* FOOTER ----------------------------------------------- */
#footer{margin-bottom:0px;text-shadow:0px 1px 0px #fff;} #copyrights{color:#374142;background:#EDEDED;text-align:center;padding:20px 0} #copyrights a{color:#374142} #copyrights a:hover{color:#374142;text-decoration:none} #credits{color:#777;text-align:center;font-size:11px;padding:10px 0 0 0} #credits a{color:#777;text-decoration:none} #credits a:hover{text-decoration:none;color:#a0ce4e} .crelink {float:right;text-align:right;} #footer-widgets{background:#F8F8F8;padding:20px 0 0 0;text-shadow:0px 1px 0px #fff;} .footer-widget-box{width:300px;float:left;margin-left:15px} .footer-widget-box-last{} #footer-widgets .widget-container{color:#374142;} #footer-widgets .widget-container a{text-decoration:none;color:#374142;} #footer-widgets .widget-container a:hover{text-decoration:none;color:#a0ce4e;} #footer-widgets h2 { padding: 0 0 1.5em 0; font-size: 19px; margin-bottom: 12px; font-family: 'BreeSerifRegular', Arial, sans-serif; background: url('http://3.bp.blogspot.com/-xRRKt2Q1O7g/UMMjZLMUm5I/AAAAAAAAJNo/47H2PtmktWU/s1600/divider.png') bottom repeat-x; } #footer-widgets .widget ul{list-style-type:none;list-style:none;margin:0px;padding:0px;} #footer-widgets .widget ul li{padding:0 0 9px 0;margin:0 0 8px 0;} .footersec {} .footersec .widget{margin-bottom:20px;} .footersec ul{} .footersec ul li{}
/* Comments----------------------------------------------- */
#comments{padding:10px;background-color:#fff;border:0px dashed #ddd;} #comments h4{font-size:16px;font-weight:bold;margin:1em 0;color:$sidebarcolor} #comments-block3{padding:0;margin:0;float:left;overflow:hidden;position:relative;} #comment-name-url{width:465px;float:left} #comment-date{width:465px;float:left;margin-top:5px;font-size:10px;} #comment-header{float:left;padding:5px 0 40px 10px;margin:5px 0px 15px 0px;position:relative;background-color:#fff;border:1px dashed #ddd;} .avatar-image-container{background:url(http://1.bp.blogspot.com/-cewCXF9l764/UC7eon7rxXI/AAAAAAAAAww/gDiPoSuhivM/s000/comment-avatar.jpg);width:32px;height:32px;float:right;margin:5px 10px 5px 5px;border:1px solid #ddd;} .avatar-image-container img{width:32px;height:32px;} a.comments-autor-name{color:#000;font:normal bold 14px Arial,Tahoma,Verdana} a.says{color:#000;font:normal 14px Arial,Tahoma,Verdana} .says a:hover{text-decoration:none} .deleted-comment{font-style:italic;color:gray} #blog-pager-newer-link{float:$startSide} #blog-pager-older-link{float:$endSide} #blog-pager{text-align:center}
/* Profile ----------------------------------------------- */
.profile-img{float:$startSide;margin-top:0;margin-$endSide:5px;margin-bottom:5px;margin-$startSide:0;padding:4px;border:1px solid $bordercolor} .profile-data{margin:0;text-transform:uppercase;letter-spacing:.1em;font:$postfooterfont;color:$sidebarcolor;font-weight:bold;line-height:1.6em} .profile-datablock{margin:.5em 0 .5em} .profile-textblock{margin:0.5em 0;line-height:1.6em} .avatar-image-container{background:url(http://1.bp.blogspot.com/-cewCXF9l764/UC7eon7rxXI/AAAAAAAAAww/gDiPoSuhivM/s000/comment-avatar.jpg);width:32px;height:32px;float:right;margin:5px 10px 5px 5px;border:1px solid #ddd;} .avatar-image-container img{width:32px;height:32px;} .profile-link{font:$postfooterfont;text-transform:uppercase;letter-spacing:.1em} #navbar-iframe{height:0;visibility:hidden;display:none;} .post h2 { font-weight:normal; color: #494949; font-size: 45px; line-height: 50px; text-decoration: none; margin-bottom: 10px; font-family: 'BreeSerifRegular', Arial, sans-serif; } .post h3 { font-family: 'BreeSerifRegular', Arial, sans-serif; font-size: 32px; line-height: 40px; margin: 10px 0; border-bottom: 4px solid #eee; font-family: 'BreeSerifRegular', Arial, sans-serif; } .post h4 { font-family: 'BreeSerifRegular', Arial, sans-serif; font-size: 28px; line-height: 40px; margin: 10px 0; font-family: 'BreeSerifRegular', Arial, sans-serif; } .post h5 { font-family: 'BreeSerifRegular', Arial, sans-serif; font-size: 24px; line-height: 40px; margin: 10px 0; font-family: 'BreeSerifRegular', Arial, sans-serif; } .post h6 { font-family: 'BreeSerifRegular', Arial, sans-serif; font-size: 18px; line-height: 40px; margin: 10px 0; font-family: 'BreeSerifRegular', Arial, sans-serif; } @font-face { font-family: 'BreeSerifRegular'; src: local('Bree Serif'), local('BreeSerif-Regular'), url(http://themes.googleusercontent.com/static/fonts/breeserif/v2/LQ7WLTaITDg4OSRuOZCpsxsxEYwM7FgeyaSgU71cLG0.woff) format('woff'); font-weight: normal; font-style: normal; }
/*-[ Read more link]---------------------------*/
.readmore { background: #99cc66; cursor: pointer; color: white!important; padding: 8px 16px; margin: 20px 0 0 0; float: right; -webkit-border-radius: 5px; -moz-border-radius: 5px; -o-border-radius: 5px; -ms-border-radius: 5px; -khtml-border-radius: 5px; border-radius: 5px; -webkit-transition: all 0.25s linear; -moz-transition: all 0.25s linear; transition: all 0.25s linear; } a.readmore:hover { text-decoration: none; background:#333; color:#fff!important; }
/*Post Meta---------------------------*/
#post-line{border: 3px solid #99cc66; margin-top:100px; width:100%; } .theauthor { font-size: 16px; margin: 0 15px 0 0; float: left; margin-top: 2px; } .theauthor a { color: #444; text-decoration: none; } .headline_meta { color: #999; font-style: italic; font-family: Georgia,serif; padding: 1px 0 15px; margin: 0 0 5px 0; border-bottom: 1px #EEE dashed; overflow: hidden; width:1000px; } .thetime { background: url(http://2.bp.blogspot.com/-RdZiQPTzU9Y/UMMjq-dtTCI/AAAAAAAAJNw/2r0VGjqayfY/s1600/sprite1.png) 0 0px no-repeat; padding: 2px 15px 0 20px; float:left; } .thecategories { background: url(http://2.bp.blogspot.com/-RdZiQPTzU9Y/UMMjq-dtTCI/AAAAAAAAJNw/2r0VGjqayfY/s1600/sprite1.png) 0 -35px no-repeat; padding: 2px 15px 0 20px; float:left; } .thecomments { background: url(http://2.bp.blogspot.com/-RdZiQPTzU9Y/UMMjq-dtTCI/AAAAAAAAJNw/2r0VGjqayfY/s1600/sprite1.png) 0 -66px no-repeat; padding: 2px 15px 0 20px; float: left; margin-top:-18px; margin-left:130px; } .post ul {list-style:circle; }
/*Comments---------------------------*/
#comments{margin:20px 20px 0;overflow:hidden} #comments h4{display:inline;padding:10px;line-height:40px} #comments h4,.comments .comment-header,.comments .comment-thread.inline-thread .comment{position:relative} #comments h4,.comments .continue a{background:#99cc66} #comments h4,.comments .user a,.comments .continue a{font-size:16px} #comments h4,.comments .continue a{font-weight:normal;color:#fff} #comments h4:after{content:"";position:absolute;bottom:-10px;left:10px;border-top:10px solid #99cc66;border-right:20px solid transparent;width:0;height:0;line-height:0} #comments .avatar-image-container img{border:0} .comment-thread{color:#111} .comment-thread a{color:#777} .comment-thread ol{margin:0 0 20px} .comment-thread .comment-content a,.comments .user a,.comments .comment-thread.inline-thread .user a{color:#669933} .comments .avatar-image-container,.comments .avatar-image-container img{width:48px;max-width:48px;height:48px;max-height:48px} .comments .comment-block,.comments .comments-content .comment-replies,.comments .comment-replybox-single{margin-left:60px} .comments .comment-block,.comments .comment-thread.inline-thread .comment{border:1px solid #ddd;background:#eeede7;padding:10px} .comments .comments-content .comment{margin:15px 0 0;padding:0;width:100%;line-height:1em} .comments .comments-content .icon.blog-author{position:absolute;top:-12px;right:-12px;margin:0;background-image: url(http://3.bp.blogspot.com/-xqN0nTWnWpE/UMMsqKVG0sI/AAAAAAAAJQA/xElYEBIxGV8/s1600/aUTHOR.png);width:36px;height:36px} .comments .comments-content .inline-thread{padding:0 0 0 20px} .comments .comments-content .comment-replies{margin-top:0} .comments .comment-content{padding:5px 0;line-height:1.4em} .comments .comment-thread.inline-thread{border-left:1px solid #ddd;background:transparent} .comments .comment-thread.inline-thread .comment{width:auto} .comments .comment-thread.inline-thread .comment:after{content:"";position:absolute;top:10px;left:-20px;border-top:1px solid #ddd;width:10px;height:0px} .comments .comment-thread.inline-thread .comment .comment-block{border:0;background:transparent;padding:0} .comments .comment-thread.inline-thread .comment-block{margin-left:48px} .comments .comment-thread.inline-thread .user a{font-size:13px} .comments .comment-thread.inline-thread .avatar-image-container,.comments .comment-thread.inline-thread .avatar-image-container img{width:36px;max-width:36px;height:36px;max-height:36px} .comments .continue{border-top:0;width:100%} .comments .continue a{padding:10px 0;text-align:center} .comment .continue{display:none} #comment-editor{width:103%!important} .comment-form{width:100%;max-width:100%}
/*************************************
-	TP ARROWS 	-
**************************************/
.tp-leftarrow.large { z-index:100;cursor:pointer; position:relative; background:url(http://3.bp.blogspot.com/-SQM1wHB9bzI/UMEk6QJIMsI/AAAAAAAAJEU/IAMrBF1KOLI/s1600/arrow_large_left.png) no-Repeat top left; width:46px; height:46px; margin-left:20px; margin-top:-23px; } .tp-rightarrow.large { z-index:100;cursor:pointer; position:relative; background:url(http://1.bp.blogspot.com/-47Wb11MQgmM/UMEk7Bnt8VI/AAAAAAAAJEY/I3xJRrDlbLE/s1600/arrow_large_right.png) no-Repeat top left; width:46px; height:46px; margin-left:-20px; margin-top:-23px; } .tp-leftarrow:hover, .tp-rightarrow:hover { background-position:bottom left; } .tp-loader { background:url(http://2.bp.blogspot.com/-7mnuR5hkW10/UMElGpctJuI/AAAAAAAAJEk/EoZK6R5IcG8/s1600/loader.gif) no-repeat 10px 10px; background-color:#fff; margin:-22px -22px; top:50%; left:50%; z-index:10000; position:absolute;width:44px;height:44px; border-radius: 3px; -moz-border-radius: 3px; -webkit-border-radius: 3px; }
/*These are custom Avada styles*/
.avada_big_black_text{ position: absolute; color: #333333; font-size: 42px; line-height: 45px; font-family: museoslab500regular; } .avada_big_black_text_center{ position: absolute; color: #333333; font-size: 38px; line-height: 45px; font-family: museoslab500regular; text-align: center; } .avada_med_green_text{ position: absolute; color: #A0CE4E; font-size: 24px; line-height: 24px; font-family: PTSansRegular, Arial, Helvetica, sans-serif; } .avada_small_gray_text{ position: absolute; color: #747474; font-size: 13px; line-height: 20px; font-family: PTSansRegular, Arial, Helvetica, sans-serif; } .avada_block_black{ position: absolute; color: #A0CE4E; text-shadow: none; font-size: 22px; line-height: 34px; padding: 0px 10px; padding-top: 1px; margin: 0px; border-width: 0px; border-style: none; background-color:#000; font-family: PTSansRegular, Arial, Helvetica, sans-serif; } .avada_block_green{ position: absolute; color: #000; text-shadow: none; font-size: 22px; line-height: 34px; padding: 0px 10px; padding-top: 1px; margin: 0px; border-width: 0px; border-style: none; background-color:#A0CE4E; font-family: PTSansRegular, Arial, Helvetica, sans-serif; } .avada_block_white{ position: absolute; color: #fff; text-shadow: none; font-size: 22px; line-height: 34px; padding: 0px 10px; padding-top: 1px; margin: 0px; border-width: 0px; border-style: none; background-color:#000; font-family: PTSansRegular, Arial, Helvetica, sans-serif; } /*These are default styles*/ .caption.black{ color: #000; text-shadow: none; } .caption.noshadow { text-shadow: none; } .caption a { color: #ff7302; text-shadow: none; -webkit-transition: all 0.2s ease-out; -moz-transition: all 0.2s ease-out; -o-transition: all 0.2s ease-out; -ms-transition: all 0.2s ease-out; } .caption a:hover { color: #ffa902; } .wp-caption{} .wp-caption-text{} .sticky{} .gallery-caption{} .bypostauthor{} #wpadminbar *{color:#ccc !important;} /* Alignment */ .alignleft { display: inline; float: left; margin-right: 15px; } .alignright { display: inline; float: right; margin-left: 15px; } .aligncenter { clear: both; display: block; margin-left: auto; margin-right: auto; }
/* Button */
.buttons a{ margin-right:30px; } .button{ display:inline-block; } .button.large{ height:43px; line-height:43px; font:13px/43px 'PTSansBold', arial, helvetica, sans-serif; text-transform:uppercase; text-align:center; text-shadow:0 1px 0 #fff; padding:0 30px; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.2); -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.2); box-shadow: 0 1px 1px rgba(0,0,0,0.2); } .button.small{ height:32px; font:13px/32px 'PTSansBold', arial, helvetica, sans-serif; text-transform:uppercase; text-align:center; text-shadow:0 1px 0 #fff; padding:0 20px; -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.2); -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.2); box-shadow: 0 1px 1px rgba(0,0,0,0.2); } .button.green{ color:#54770f !important; background-image: linear-gradient(top, #D1E990 0%, #AAD75D 100%); background-image: -o-linear-gradient(top, #D1E990 0%, #AAD75D 100%); background-image: -moz-linear-gradient(top, #D1E990 0%, #AAD75D 100%); background-image: -webkit-linear-gradient(top, #D1E990 0%, #AAD75D 100%); background-image: -ms-linear-gradient(top, #D1E990 0%, #AAD75D 100%); background-image: -webkit-gradient( linear, left top, left bottom, color-stop(0, #D1E990), color-stop(1, #AAD75D) ); border:1px solid #9dba60; } .button.green:hover{ color:#54770f !important; background-image: linear-gradient(top, #AAD75D 0%, #D1E990 100%); background-image: -o-linear-gradient(top, #AAD75D 0%, #D1E990 100%); background-image: -moz-linear-gradient(top, #AAD75D 0%, #D1E990 100%); background-image: -webkit-linear-gradient(top, #AAD75D 0%, #D1E990 100%); background-image: -ms-linear-gradient(top, #AAD75D 0%, #D1E990 100%); background-image: -webkit-gradient( linear, left top, left bottom, color-stop(0, #AAD75D), color-stop(1, #D1E990) ); border:1px solid #9dba60; } .no-cssgradients .button.green{ background-color:#D1E990; } .no-cssgradients .button.green:hover{ background-color:#AAD75D; } @font-face { font-family: 'MuseoSlab500Regular'; src: url('http://theme-fusion.com/avadatest/wp-content/uploads/2012/11/Museo_Slab_500-webfont2.eot'); src: url('http://theme-fusion.com/avadatest/wp-content/uploads/2012/11/Museo_Slab_500-webfont2.eot?#iefix') format('embedded-opentype'), url('http://theme-fusion.com/avadatest/wp-content/uploads/2012/11/Museo_Slab_500-webfont2.svg#MuseoSlab500Regular') format('svg'), url('http://theme-fusion.com/avadatest/wp-content/uploads/2012/11/Museo_Slab_500-webfont2.woff') format('woff'), url('http://theme-fusion.com/avadatest/wp-content/uploads/2012/11/Museo_Slab_500-webfont2.ttf') format('truetype'); font-weight: normal; font-style: normal; }
.shadow-left2{ position:absolute; background-image:url(http://4.bp.blogspot.com/-8Z_Td_MOMgY/UMEoigC25wI/AAAAAAAAJE0/X1-5xD9y4ds/s1600/shadow-top.png); background-repeat:no-repeat; background-position:top center; height:42px; width:100%; top:0; z-index:100; width:960px; margin-top:85px; .shadow-left3{ position:absolute; background-image:url(http://4.bp.blogspot.com/-8Z_Td_MOMgY/UMEoigC25wI/AAAAAAAAJE0/X1-5xD9y4ds/s1600/shadow-top.png); background-repeat:no-repeat; background-position:top center; height:42px; width:100%; top:0; z-index:100; width:960px; margin-top:85px;
}

-->
</style>
<style> nav#nav{ float:right; font:14px/16px 'MuseoSlab500Regular', arial, helvetica, sans-serif; margin-top: -85px; z-index: 99999 } #nav ul{ list-style:none; margin:0; padding:0; } #nav ul li{ float:left; padding: 0 49px 0 0; margin: 0; } #nav ul a,#nav li.current-menu-ancestor a{ display:block; height:83px; line-height:83px; border-top:3px solid #fff; } #nav ul .current_page_item a, #nav ul .current-menu-item a, #nav ul > .current-menu-parent a{ color:#a0ce4e; text-decoration:none; border-color:#a0ce4e; } #nav ul li{ position:relative; } #nav ul ul{ display:none; position:absolute;top:86px;left:0; width:170px; background:#edebeb; z-index:100000; border-top:3px solid #a0ce4e; z-index: 99999; } #nav ul li:hover ul{ display:block; } #nav ul li ul li{ display:block; float:none; margin:0; padding: 0; } #wrapper #nav ul li ul li a{ border:0; height:30px; text-indent:20px; font:13px/30px 'PTSansRegular', Arial, Helvetica, sans-serif; color:#333333 !important; } #wrapper #nav ul li ul li a:hover,#wrapper #nav ul li ul li.current-menu-item a{ background-color:rgba(255,255,255,0.5); } #nav ul ul ul{ display:none !important; } #nav ul ul li:hover ul{ display:block !important; top:-3px;left:170px; } #nav select{ max-width:100%; display:none; } #fallback-slide{display:none;} #wrapper #nav ul ul ul ul{display:none !important;} #wrapper #nav ul ul ul li:hover ul{display:block !important;} </style>
<script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/cb=gapi.loaded_4" async=""></script><script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/cb=gapi.loaded_3" async=""></script><script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/cb=gapi.loaded_2" async=""></script><script type="text/javascript" async="" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/plusone.js.tải xuống" gapi_processed="true"></script><script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/cb=gapi.loaded_1" async=""></script><script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/cb=gapi.loaded_0" async=""></script><script type="text/javascript">
var thumbnail_mode = "float" ;
summary_noimg = 460;
summary_img = 460;
img_thumb_height = 200;
img_thumb_width = 200;
</script>
<script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/excerpt_min.js.tải xuống" type="text/javascript"></script>
<link href="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/authorization.css" media="all" onload="if(media!=&#39;all&#39;)media=&#39;all&#39;" rel="stylesheet">
<noscript><link href='https://www.blogger.com/dyn-css/authorization.css?targetBlogID=6803739683768993764&amp;zx=135bde1c-9b70-41e0-bfd2-34472ea98395' rel='stylesheet'/></noscript>

<script type="text/javascript" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/f.txt"></script><style>
.gc-bubbleDefault{background-color:transparent !important;text-align:left;padding:0 !important;margin:0 !important;border:0 !important;table-layout:auto !important}.gc-reset{background-color:transparent !important;border:0 !important;padding:0 !important;margin:0 !important;text-align:left}.pls-bubbleTop{border-bottom:1px solid #ccc !important}.pls-topTail,.pls-vertShimLeft,.pls-contentLeft{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/border_3.gif) !important}.pls-topTail{background-repeat:repeat-x !important;background-position:bottom !important}.pls-vertShim{background-color:#fff !important;text-align:right}.tbl-grey .pls-vertShim{background-color:#f5f5f5 !important}.pls-vertShimLeft{background-repeat:repeat-y !important;background-position:right !important;height:4px}.pls-vertShimRight{height:4px}.pls-confirm-container .pls-vertShim{background-color:#fff3c2 !important}.pls-contentWrap{background-color:#fff !important;position:relative !important;vertical-align:top}.pls-contentLeft{background-repeat:repeat-y;background-position:right;vertical-align:top}.pls-dropRight{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleDropR_3.png) !important;background-repeat:repeat-y !important;vertical-align:top}.pls-vert,.pls-tailleft,.pls-dropTR .pls-dropBR,.pls-dropBL,.pls-vert img{vertical-align:top}.pls-dropBottom{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleDropB_3.png) !important;background-repeat:repeat-x !important;width:100%;vertical-align:top}.pls-topLeft{background:inherit !important;text-align:right;vertical-align:bottom}.pls-topRight{background:inherit !important;text-align:left;vertical-align:bottom}.pls-bottomLeft{background:inherit !important;text-align:right}.pls-bottomRight{background:inherit !important;text-align:left;vertical-align:top}.pls-tailtop,.pls-tailright,.pls-tailbottom,.pls-tailleft{display:none;position:relative}.pls-tailbottom,.pls-tailtop,.pls-tailright,.pls-tailleft,.pls-dropTR,.pls-dropBR,.pls-dropBL{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleSprite_3.png) !important;background-repeat:no-repeat}.tbl-grey .pls-tailbottom,.tbl-grey .pls-tailtop,.tbl-grey .pls-tailright,.tbl-grey .pls-tailleft,.tbl-grey .pls-dropTR,.tbl-grey .pls-dropBR,.tbl-grey .pls-dropBL{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleSprite-grey.png) !important}.pls-tailbottom{background-position:-23px 0}.pls-confirm-container .pls-tailbottom{background-position:-23px -10px}.pls-tailtop{background-position:-19px -20px}.pls-tailright{background-position:0 0}.pls-tailleft{background-position:-10px 0}.pls-tailtop{vertical-align:top}.gc-bubbleDefault td{line-height:0;font-size:0}.pls-topLeft img,.pls-topRight img,.pls-tailbottom{vertical-align:bottom}.pls-bottomLeft img,.bubbleDropTR,.pls-dropBottomL img,.pls-dropBottom img,.pls-dropBottomR img,.pls-bottomLeft{vertical-align:top}.pls-dropTR{background-position:0 -22px}.pls-dropBR{background-position:0 -27px}.pls-dropBL{background-position:0 -16px}.pls-spacertop,.pls-spacerright,.pls-spacerbottom,.pls-spacerleft{position:static !important}.pls-spinner{bottom:0;position:absolute;left:0;margin:auto;right:0;top:0} 
.style82 {font-size: 20px}
.style83 {
	font-size: 25px;
	color: #FFFFFF;
}
</style><script async="" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/lazy.min.js.tải xuống"></script></head>
<body>
<div id="wrap1">
<div id="body-wrapper"><div id="outer-wrapper">
<div id="header-wrapper">
<div class="headerleft">
<div class="headerleft section" id="headerleft"><div class="widget Header" data-version="1" id="Header1">
<div id="header-inner">
<a href="trangchu.php" style="display: block">
<img alt="MBL Avada" height="36px; " id="Header1_headerimg" src="img/210.png" style="display: block;padding-left:0px;padding-top:0px;" width="250px; ">
</a>
</div>
</div></div>
</div>
<div id="header-wrapper2">
<div class="header section" id="header2"><div class="widget HTML" data-version="1" id="HTML2">
<div class="widget-content">
<script type="text/javascript">
</script>
</div>
<div class="clear"></div>
<span class="widget-item-control">
<span class="item-control blog-admin">
<a class="quickedit" href="http://www.blogger.com/rearrange?blogID=6803739683768993764&amp;widgetType=HTML&amp;widgetId=HTML2&amp;action=editWidget&amp;sectionId=header2" onclick="return _WidgetManager._PopupConfig(document.getElementById(&quot;HTML2&quot;));" target="configHTML2" title="Edit">
<img alt="" height="18" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/icon18_wrench_allbkg.png" width="18">
</a>
</span>
</span>
<div class="clear"></div>
</div></div>
<div style="clear:both;"></div>
</div>
</div>
<div id="wrapper">
<nav class="nav-holder" id="nav">
<ul class="menu" id="nav">
<li><a href="trangchu.php">Home</a></li>
<li><a href="#">Danh Mục Sách</a>
<ul class="sub-menu">
<li><a href="#">Chuyên Ngành</a>
	<ul class="sub-menu">
	<li><a href="CNTT.php">CNTT</a></li>
	<li><a href="mamnon.php">Mầm Non</a></li>
	<li><a href="ngonnguanh.php">Ngôn Ngữ Anh</a></li>
	<li><a href="taichinhnganhang.php">Tài Chính - Ngân Hàng</a></li>
	<li><a href="quantrivanphong.php">Quản Trị Văn Phòng</a></li>
	<li><a href="luat.php">Luật</a></li>
	<li><a href="kythuatdien.php">Kỹ Thuật Điện</a></li>
	<li><a href="thuy.php">Thú Y</a></li>
	<li><a href="#">Thêm</a>
		<ul class="sub-menu">
		<li><a href="nongnghiep.php">Nông Nghiệp</a></li>
		<li><a href="thuysan.php">Thủy Sản</a></li>
		<li><a href="cokhi.php">Cơ Khí</a></li>
		<li><a href="hoahoc.php">Hóa Hoc</a></li>
		<li><a href="duoc.php">Dược</a></li>
		<li><a href="ketoan.php">Kế Toán</a></li>
		<li><a href="congnghesinhhoc.php">Công Nghệ Sinh Học</a></li>
		<li><a href="kientruc.php">Kiến Trúc</a></li>
	</ul>
	</li>
	</ul>
<li><a href="truyendongluc.php">Truyền Động Lực</a></li>
<li><a href="khoahoc.php">Khoa Học</a></li>
<li><a href="tamhon.php">Tâm Hồn</a></li>
<li><a href="truyentieuthuyet.php">Truyện -Tiểu Thuyết</a></li>
	</ul>
</li>

<li><a href="dangxuat.php">Đăng Xuất</a></li>
<li></li>
</ul>
</nav>
</div>

<div class="main section" id="main"><div class="widget Blog" data-version="1" id="Blog1">
<div class="blog-posts hfeed">

<!--Can't find substitution for tag [defaultAdStart]-->

      
<!--Can't find substitution for tag [adEnd]-->
</div>
<table width="991" border="0" align="center">
  <tr>
    <td height="27" colspan="2" bgcolor="#FFFFFF"></td>
    <td width="475" rowspan="4"  bgcolor="#FFFFFF"></td>
  </tr>
  </table>
 <table width="50" border="0" align="center">
  <tr>
    <td height="10" colspan="2" align="right" valign="bottom" bgcolor="#FFFFFF"><form action="timkiem.php" method="post" name="form1" class="style6" id="form1">

            <input name="textfield" type="text" size="29" />
            <input type="submit" value="T&igrave;m" name="search" />

</form></td>
  </tr>
  </table>

 <p align="center"></p>
 <label></label>
 <table width="806" border="0" align="center">
  <tr>
    <td width="84" background="img/030.jpg" bgcolor="#FFFFFF">&nbsp;</td>
    <td width="2" height="31" background="img/030.jpg" bgcolor="#0000FF">&nbsp;</td>
    <td width="372" bgcolor="#FFCC66"><div align="center" class="style10 style82">Nhập tên tài khoản cần xóa: </div></td>
    <td width="518" background="img/030.jpg" class="style9"><form id="form2" name="form2" method="post" action="xoataikhoan2.php">
      <div align="center">
        <input name="user" type="text" size="30" />
        <input type="submit" name="Kiểm Tra" value="Kiểm Tra" />
      </div>
    </form></td>
  </tr>
 </table>
 <p align="center">&nbsp;</p>
 <p><?php
	$dem=0;
  if (mysqli_num_rows($result1) > 0)
	{
   		 // output data of each row
   		 while($row1 = mysqli_fetch_assoc($result1))
		 {
		 	if($row1["usename"] == $_POST['user'])
			{
				if($dem==0)
				{
?>
<?php $dem=1;}?>
<table width="992" border="0" align="center">
  <tr>
    <td width="982"><form id="form2" name="form2" method="post" action="xoatk.php">
      <label></label>
      <label></label>
      <label></label>

        <div align="center">
          <label>
          <input name="usename" type="text" value="<?php echo $row1["usename"];?>" size="40" readonly="False" />
          <input name="hoten" type="text" value="<?php echo $row1["hoten"];?>" size="30" readonly="False" />
          <input name="lop" type="text" value="<?php echo $row1["lop"];?>" size="7" readonly="False" />
          </label>
          <input type="submit" name="Submit" value="Xóa" />

        </div>
    </form>    </td>
  </tr>
</table>
<?php
			$dem=1;}

?>
<?php if($_POST['user']=="ALL"){ ?>
<table width="992" border="0" align="center">
  <tr>
    <td width="982"><form id="form2" name="form2" method="post" action="xoatk.php">
      <label></label>
      <label></label>
      <label></label>

        <div align="center">
          <label>
          <input name="usename" type="text" value="<?php echo $row1["usename"];?>" size="40" readonly="False" />
          <input name="hoten" type="text" value="<?php echo $row1["hoten"];?>" size="30" readonly="False" />
          <input name="lop" type="text" value="<?php echo $row1["lop"];?>" size="7" readonly="False" />
          </label>
          <input type="submit" name="Submit" value="Xóa" />

        </div>
    </form>    </td>
  </tr>
</table>
<?php $dem=1;}}} ?>
<?php
	if($dem==0)
	{
?>
<br />
<table width="575" border="0" align="center">
  <tr>
    
    <td width="569" align="center" valign="middle" bordercolor="#0000FF" bgcolor="#0000FF" class="style12 style11 style83">&nbsp; <?php echo "KHÔNG TÌM THẤY";?></td>
  </tr>
</table>
<?php
	}
?><br />
   
            <br />
  </p>
 </div>

<script type="text/javascript">window.___gcfg = {'lang': 'en'};</script>

<div class="clear"></div>
<span class="widget-item-control">
<span class="item-control blog-admin">
<a class="quickedit" href="http://www.blogger.com/rearrange?blogID=6803739683768993764&amp;widgetType=BlogArchive&amp;widgetId=BlogArchive1&amp;action=editWidget&amp;sectionId=sidebartab1" onclick="return _WidgetManager._PopupConfig(document.getElementById(&quot;BlogArchive1&quot;));" target="configBlogArchive1" title="Edit">
<img alt="" height="18" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/icon18_wrench_allbkg.png" width="18">
</a>
</span>
</span>
<div class="clear"></div>
</div>
</div></div>
</div>
<div style="height:5px;clear:both;"></div>
<div class="sidebar no-items section" id="sidebarright"></div>
<p></p></div>
<!-- spacer for skins that want sidebar and main to be the same height-->
<div class="clear">&nbsp;</div>
</div>
<!-- end content-wrapper -->

<div class="clear"></div>
</div>
</div></div>
</li>
</ul>
</div>
</div>
</div>
<div style="clear:both;"></div>
<div id="footer-container">
<div id="footer">
<div id="copyrights">
Copyright © <script type="text/javascript">var creditsyear = new Date();document.write(creditsyear.getFullYear());</script>
 | Designed by Sinh Viên NCKH Trường DHTV</a>
</div>
</div><!-- #footer -->
</div>
</div></div>
<!-- end outer-wrapper -->
<style type="text/css"> .clearfix:after{content:"\0020";display:block;height:0;clear:both;visibility:hidden;overflow:hidden} #container,#header,#main,#main-fullwidth,#footer,.clearfix{display:block} .clear{clear:both} h1,h2,h3,h4,h5,h6{margin-bottom:16px;font-weight:normal;line-height:1} h1{font-size:40px} h2{font-size:30px} h3{font-size:20px} h4{font-size:16px} h5{font-size:14px} h6{font-size:12px} h1 img,h2 img,h3 img,h4 img,h5 img,h6 img{margin:0} table{margin-bottom:20px;width:100%} th{font-weight:bold} thead th{background:#c3d9ff} th,td,caption{padding:4px 10px 4px 5px} tr.even td{background:#e5ecf9} tfoot{font-style:italic} caption{background:#eee} li ul,li ol{margin:0} ul,ol{margin:0 20px 20px 0;padding-left:40px} ul{list-style-type:disc} ol{list-style-type:decimal} dl{margin:0 0 20px 0} dl dt{font-weight:bold} dd{margin-left:20px} blockquote{margin:20px;color:#666;} pre{margin:20px 0;white-space:pre} pre,code,tt{font:13px 'andale mono','lucida console',monospace;line-height:18px} #search {overflow:hidden;} #header h1{font-family:'Oswald',Arial,Helvetica,Sans-serif;} #header .description{font-family:Arial,Helvetica,Sans-serif;} .post-title {font-family:Arial,Helvetica,Sans-serif;} #footer-widgets .widgettitle{font-family:'Oswald', sans-serif;} /* -- number page navigation -- */ #blog-pager {padding:6px;font-size:11px;} #comment-form iframe{padding:5px;width:580px;height:275px;} .PopularPosts .item-title{ list-style: none!important; margin-left: 0!important; padding: 10px 0; border-bottom: 1px dashed #EEE; overflow: hidden; -webkit-transition: all 0.25s linear; -moz-transition: all 0.25s linear; transition: all 0.25s linear; } .PopularPosts .item-title li:hover { background:#f7f7f7; padding-left: 10px; } .widget-container{list-style-type:none;list-style:none;margin:0 0 15px 0;padding:0;color:#374142;font-size:13px} .widget-container2{list-style-type:none;list-style:none;margin:5px 15px 10px 0px;padding:0;color:#374142;font-size:13px} h3.widgettitle{background:url(http://1.bp.blogspot.com/-gFwNIT6i-gU/UC7emWzTiOI/AAAAAAAAAwg/9Wu_6pl6AoM/s000/widgettitle-bg.png) left top repeat-x;margin:0 0 10px 0;padding:9px 0 9px 10px;color:#FFF;font-size:16px;line-height:16px;font-family:'Oswald',sans-serif;font-weight:normal;text-decoration:none;text-transform:uppercase;text-shadow:0px 1px 0px #000;} div.span-1,div.span-2,div.span-3,div.span-4,div.span-5,div.span-6,div.span-7,div.span-8,div.span-9,div.span-10,div.span-11,div.span-12,div.span-13,div.span-14,div.span-15,div.span-16,div.span-17,div.span-18,div.span-19,div.span-20,div.span-21,div.span-22,div.span-23,div.span-24{float:left;margin-right:10px} .span-1{width:30px}.span-2{width:70px}.span-3{width:110px}.span-4{width:150px}.span-5{width:190px}.span-6{width:230px}.span-7{width:270px}.span-8{width:310px}.span-9{width:350px}.span-10{width:390px}.span-11{width:430px}.span-12{width:470px}.span-13{width:510px}.span-14{width:550px}.span-15{width:590px}.span-16{width:630px}.span-17{width:670px}.span-18{width:710px}.span-19{width:750px}.span-20{width:790px}.span-21{width:830px}.span-22{width:870px}.span-23{width:910px}.span-24,div.span-24{width:960px;margin:0}input.span-1,textarea.span-1,input.span-2,textarea.span-2,input.span-3,textarea.span-3,input.span-4,textarea.span-4,input.span-5,textarea.span-5,input.span-6,textarea.span-6,input.span-7,textarea.span-7,input.span-8,textarea.span-8,input.span-9,textarea.span-9,input.span-10,textarea.span-10,input.span-11,textarea.span-11,input.span-12,textarea.span-12,input.span-13,textarea.span-13,input.span-14,textarea.span-14,input.span-15,textarea.span-15,input.span-16,textarea.span-16,input.span-17,textarea.span-17,input.span-18,textarea.span-18,input.span-19,textarea.span-19,input.span-20,textarea.span-20,input.span-21,textarea.span-21,input.span-22,textarea.span-22,input.span-23,textarea.span-23,input.span-24,textarea.span-24{border-left-width:1px!important;border-right-width:1px!important;padding-left:5px!important;padding-right:5px!important}input.span-1,textarea.span-1{width:18px!important}input.span-2,textarea.span-2{width:58px!important}input.span-3,textarea.span-3{width:98px!important}input.span-4,textarea.span-4{width:138px!important}input.span-5,textarea.span-5{width:178px!important}input.span-6,textarea.span-6{width:218px!important}input.span-7,textarea.span-7{width:258px!important}input.span-8,textarea.span-8{width:298px!important}input.span-9,textarea.span-9{width:338px!important}input.span-10,textarea.span-10{width:378px!important}input.span-11,textarea.span-11{width:418px!important}input.span-12,textarea.span-12{width:458px!important}input.span-13,textarea.span-13{width:498px!important}input.span-14,textarea.span-14{width:538px!important}input.span-15,textarea.span-15{width:578px!important}input.span-16,textarea.span-16{width:618px!important}input.span-17,textarea.span-17{width:658px!important}input.span-18,textarea.span-18{width:698px!important}input.span-19,textarea.span-19{width:738px!important}input.span-20,textarea.span-20{width:778px!important}input.span-21,textarea.span-21{width:818px!important}input.span-22,textarea.span-22{width:858px!important}input.span-23,textarea.span-23{width:898px!important}input.span-24,textarea.span-24{width:938px!important}.last{margin-right:0;padding-right:0} .last,div.last{margin-right:0} </style>
<script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/plusone.js(1).tải xuống" type="text/javascript" gapi_processed="true"> {lang: 'en-US'} </script>
<script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/jquery-1.7.1.min.js.tải xuống" type="text/javascript"></script>
<script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/related-posts.js.tải xuống" type="text/javascript"></script>
</div>
<script src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/plusone.js.tải xuống" type="text/javascript" gapi_processed="true"></script>

<script type="text/javascript" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/1882756525-widgets.js.tải xuống"></script>
<script type="text/javascript">
window['__wavt'] = 'AOuZoY5t8xAYo9KvkHEElteQ_DFkhmB6Aw:1529032054093';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d6803739683768993764','//avada-mbl.blogspot.com/','6803739683768993764');
_WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '6803739683768993764', 'title': 'MBL Avada', 'url': 'http://avada-mbl.blogspot.com/', 'canonicalUrl': 'http://avada-mbl.blogspot.com/', 'homepageUrl': 'http://avada-mbl.blogspot.com/', 'searchUrl': 'http://avada-mbl.blogspot.com/search', 'canonicalHomepageUrl': 'http://avada-mbl.blogspot.com/', 'blogspotFaviconUrl': 'http://avada-mbl.blogspot.com/favicon.ico', 'bloggerUrl': 'https://www.blogger.com', 'hasCustomDomain': false, 'httpsEnabled': true, 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': '', 'encoding': 'UTF-8', 'locale': 'en', 'localeUnderscoreDelimited': 'en', 'languageDirection': 'ltr', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22MBL Avada - Atom\x22 href\x3d\x22http://avada-mbl.blogspot.com/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22MBL Avada - RSS\x22 href\x3d\x22http://avada-mbl.blogspot.com/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22MBL Avada - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/6803739683768993764/posts/default\x22 /\x3e\n', 'meTag': '', 'openIdOpTag': '\x3clink rel\x3d\x22openid.server\x22 href\x3d\x22https://www.blogger.com/openid-server.g\x22 /\x3e\n\x3clink rel\x3d\x22openid.delegate\x22 href\x3d\x22http://avada-mbl.blogspot.com/\x22 /\x3e\n', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'adsenseHasAds': false, 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/95819a1b212e1f29', 'plusOneApiSrc': 'https://apis.google.com/js/plusone.js', 'sharing': {'platforms': [{'name': 'Get link', 'key': 'link', 'shareMessage': 'Get link', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'Share to Facebook', 'target': 'facebook'}, {'name': 'BlogThis!', 'key': 'blogThis', 'shareMessage': 'BlogThis!', 'target': 'blog'}, {'name': 'Twitter', 'key': 'twitter', 'shareMessage': 'Share to Twitter', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'Share to Pinterest', 'target': 'pinterest'}, {'name': 'Google+', 'key': 'googlePlus', 'shareMessage': 'Share to Google+', 'target': 'googleplus'}, {'name': 'Email', 'key': 'email', 'shareMessage': 'Email', 'target': 'email'}], 'googlePlusShareButtonWidth': 300, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27en\x27};\x3c/script\x3e'}, 'hasCustomJumpLinkMessage': false, 'jumpLinkMessage': 'Read more', 'pageType': 'index', 'pageName': '', 'pageTitle': 'MBL Avada'}}, {'name': 'features', 'data': {'cmt_anon_warn': 'false', 'lazy_images': 'false', 'poll_static': 'true', 'sharing_get_link_dialog': 'true', 'sharing_native': 'false'}}, {'name': 'messages', 'data': {'edit': 'Edit', 'linkCopiedToClipboard': 'Link copied to clipboard!', 'ok': 'Ok', 'postLink': 'Post Link'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'Custom', 'isResponsive': false, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'MBL Avada', 'description': '', 'url': 'http://avada-mbl.blogspot.com/', 'type': 'feed', 'isSingleItem': false, 'isMultipleItems': true, 'isError': false, 'isPage': false, 'isPost': false, 'isHomepage': true, 'isArchive': false, 'isLabelSearch': false}}]);
_WidgetManager._RegisterWidget('_HeaderView', new _WidgetInfo('Header1', 'headerleft', null, document.getElementById('Header1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML2', 'header2', null, document.getElementById('HTML2'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_BlogView', new _WidgetInfo('Blog1', 'main', null, document.getElementById('Blog1'), {'cmtInteractionsEnabled': false, 'useNgc': false, 'lightboxEnabled': true, 'lightboxModuleUrl': 'https://www.blogger.com/static/v1/jsbin/3625544918-lbx.js', 'lightboxCssUrl': 'https://www.blogger.com/static/v1/v-css/368954415-lightbox_bundle.css'}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_PopularPostsView', new _WidgetInfo('PopularPosts1', 'sidebartab1', null, document.getElementById('PopularPosts1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML1', 'sidebartab1', null, document.getElementById('HTML1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_NavbarView', new _WidgetInfo('Navbar1', 'sidebartab1', null, document.getElementById('Navbar1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_AttributionView', new _WidgetInfo('Attribution1', 'sidebartab1', null, document.getElementById('Attribution1'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_BlogArchiveView', new _WidgetInfo('BlogArchive1', 'sidebartab1', null, document.getElementById('BlogArchive1'), {'languageDirection': 'ltr', 'loadingMessage': 'Loading\x26hellip;'}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML5', 'footersec1', null, document.getElementById('HTML5'), {}, 'displayModeFull'));
_WidgetManager._RegisterWidget('_ProfileView', new _WidgetInfo('Profile1', 'footersec3', null, document.getElementById('Profile1'), {}, 'displayModeFull'));
</script>

<iframe name="oauth2relay222500345" id="oauth2relay222500345" src="./MBL Avada_files/postmessageRelay.html" tabindex="-1" aria-hidden="true" style="width: 1px; height: 1px; position: absolute; top: -100px;"></iframe><link type="text/css" rel="stylesheet" href="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/368954415-lightbox_bundle.css"><script type="text/javascript" src="file:///C|/Users/TrongHao/Desktop/MBL Avada_files/3625544918-lbx.js.tải xuống"></script></body></html>