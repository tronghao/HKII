<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<table width="998" border="1" align="center">
  <tr>
    <td colspan="5"><h3 align="left" class="style7">Thư viện Trường Đại học Trà Vinh. </h3>
        <h3 align="left"><span class="style7">Số 126 - Nguyễn Thiện Thành, Khóm 4, phường 5, Thành phố Trà Vinh - Tỉnh Trà Vinh.</span><br />
      </h3></td>
    <td width="500"><img src="img/002.jpg" width="500" height="193" /></td>
  </tr>
</table>
<body>
</body>
</html>
