<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {
	color: #000000;
	font-size: 22px;
	font-weight: bold;
}
.style3 {
	font-size: 22px;
	color: #FF0000;
	font-weight: bold;
}
-->
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
.style4 {color: #6600FF}
</style>
</head>

<body>
<p align="center" class="style3">B&#7840;N KH&Ocirc;NG C&Oacute; QUY&#7872;N TRUY C&#7852;P TRANG N&Agrave;Y!</p>
<p align="center" class="style2">B&#7840;N PH&#7842;I <a href="dangnhap.php" class="style4">&#272;&#258;NG NH&#7852;P</a> &#272;&#7874; TI&#7870;P T&#7908;C! </p>
<?php
	session_start();
	session_destroy(); 
?>
</body>
</html>
