<?php
include('admin.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style6 {color: #FFFF66}
.style7 {color: #6600FF}
.style8 {color: #FFFF00}
.style9 {
	font-size: 24px;
	color: #0000FF;
}
-->
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
.style10 {
	font-size: 36px;
	color: #FF33FF;
}
.style11 {font-size: 36px; color: #0000FF; }
.style12 {font-size: 50px; color: #0000FF; }
.style13 {font-size: 45px}
.style14 {font-size: 45px; color: #FF33FF; }
.style15 {color: #FF0000}
.style20 {color: #660099; font-weight: bold; }
</style>
</head>
<body align="center">
<?php include('start.php');?>
<table width="1000" border="0" align="center">
  <tr>
    <td width="173" bgcolor="#FF99FF"><div align="center" class="style20"><a href="chuyennganh.php">CHUYÊN NGÀNH</a></div></td>
    <td width="199" bgcolor="#FF99FF"><div align="center" class="style20"><a href="truyendongluc.php">TRUYỀN ĐỘNG LỰC </a></div></td>
    <td width="168" bgcolor="#FF99FF"><div align="center" class="style20"><a href="tamhon.php">TÂM HỒN</a></div></td>
    <td width="199" bgcolor="#FF99FF"><div align="center" class="style20"><a href="khoahoc.php">KHOA HỌC</a></div></td>
    <td width="239" bgcolor="#FF99FF"><div align="center" class="style20"><a href="truyentieuthuyet.php">TRUYỆN - TIỂU THUYẾT</a></div></td>
  </tr>
</table>
<table width="999" border="0" align="center">
  <tr>
    <td height="196"><div align="left"><img src="img/014.jpg" width="993" height="290" /></div>      <div align="left"></div></td>
  </tr>
  <tr>
    <td><div align="center" class="style10"><img src="img/019.jpg" width="996" height="257" /></div>    </td>
  </tr>
</table>
<?php include('end.php');?>
<p>&nbsp;</p>
</body>
</html>
