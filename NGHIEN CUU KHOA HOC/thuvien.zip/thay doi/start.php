<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style6 {color: #FFFF66}
.style8 {color: #FFFF00}
-->
</style>
</head>

<body>
<table width="995" height="233" border="0" align="center">
  <tr>
    <td height="197" colspan="6"><img src="img/003.jpg" width="986" height="193" /></td>
  </tr>
  <tr>
    <td width="118" height="30" bgcolor="#999999"><div align="center" class="style6">
      <div align="center"><a href="trangchu.php" class="style8">TRANG CH&#7910; </a></div>
    </div></td>
    <td width="162" bgcolor="#999999"><div align="center" class="style6">
      <div align="center"><a href="danhmucsach.php" class="style8">DANH M&#7908;C S&Aacute;CH</a></div>
    </div></td>
    <td width="162" bgcolor="#999999"><div align="center"><a href="tracuumuon.php" class="style8">TRA C&#7912;U M&#431;&#7906;N </a></div></td>
    <td width="163" bgcolor="#999999"><div align="center"><a href="duyettrasach.php" class="style8">DUY&#7878;T TR&#7842; S&Aacute;CH </a></div></td>
    <td width="226" bgcolor="#999999"><form action="timkiem.php" method="post" name="form1" class="style6" id="form1">
      <div align="center">
        <input type="text" name="textfield" />
        <input type="submit" value="T&igrave;m" name="search">
      </div>
    </form></td>
    <td width="138" bgcolor="#999999"><div align="center" class="style6">
      <div align="center"><a href="dangxuat.php" class="style8">&#272;&#258;NG XU&#7844;T </a></div>
    </div></td>
  </tr>
</table>
<table width="995" height="30" border="0" align="center">
  <tr>
    <td width="173" height="26" bgcolor="#999999"><div align="center" class="style6">
      <div align="center"><a href="themsach.php" class="style8">TH&Ecirc;M S&Aacute;CH </a></div>
    </div></td>
    <td width="173" bgcolor="#999999"><div align="center" class="style6">
      <div align="center"><a href="xoasach.php" class="style8">X&Oacute;A S&Aacute;CH </a></div>
    </div></td>
    <td width="222" bgcolor="#999999"><div align="center"><a href="themtaikhoan.php" class="style8">TH&Ecirc;M T&Agrave;I KHO&#7842;N </a></div></td>
    <td width="191" bgcolor="#999999"><div align="center"><a href="xoataikhoan.php" class="style8">X&Oacute;A T&Agrave;I KHO&#7842;N </a></div></td>
    <td width="214" bgcolor="#999999"><div align="center"><a href="capnhattaikhoan.php" class="style8">C&#7852;P NH&#7852;T T&Agrave;I KHO&#7842;N</a></div></td>
  </tr>
</table>
</body>
</html>
