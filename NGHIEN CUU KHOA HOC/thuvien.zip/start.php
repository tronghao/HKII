
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style6 {color: #FFFF66}
-->
.ab:hover {
    opacity: 0.5;
    filter: alpha(opacity=50); /* For IE8 and earlier */
}
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
.style17 {
	color: #0000FF;
	font-size: 20px;
	font-weight: bold;
}
.style20 {
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
	color: #0000FF;
}
.style40 {font-family: "Times New Roman", Times, serif; font-weight: bold;}
.style47 {font-size: 20px; font-weight: bold;}
.style48 {
	font-size: 26px;
	font-family: VNI-Bandit;
}
.style51 {
	color: #0000FF;
	font-size: 20px;
}
.style55 {
	font-size: 24px;
	font-weight: bold;
	font-family: VNI-Algerian;
}
.style57 {font-size: 22px}
.style59 {font-size: 25px; color: #000099; font-family: VNI-Aztek; }
.abcd:hover {
    opacity: 0.5;
    filter: alpha(opacity=50); /* For IE8 and earlier */</style>
</head>

<body>

  <table width="987" border="0" align="center">
    <tr>
      <td width="363" rowspan="5"><img src="img/201.png" width="362" height="259" /></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td height="54" colspan="2">&nbsp;</td>
    </tr>
    
    <tr>
      <td width="240" height="72"><form action="timkiem.php" method="post" name="form1" class="style6" id="form1">
        <p>&nbsp;</p>
        <p>&nbsp;        </p>
        <p align="left">
          <input name="textfield" type="text" size="20" />
          <input type="submit" value="T&igrave;m" name="search" />
        </p>
      </form></td>
      <td width="370"><p align="right"><span class="style48">TA&Oslash;I KHOA&Ucirc;N: </span><span class="style59"><?php echo  $_SESSION['user']; ?></span></p>
        <p align="right" class="style51"><span class="style57">Xin Ch&agrave;o: </span><span class="style55">&ntilde;O&Aring; tRO&Iuml;NG hA&Ucirc;O </span></p></td>
    </tr>
    
    
    <tr>
      <td height="50" colspan="2" background="img/028.jpg"><div align="center"><a href="trangchu.php"><img src="img/206.png" width="52" height="48" border="0" class="abcd" /></a><a href="gioithieu.php"><img src="img/203.png" width="130" height="30" border="0" class="abcd" /></a><a href="danhmucsach.php"><img src="img/202.png" width="130" height="30" border="0" class="abcd" /></a><a href="thongtin.php"><img src="img/204.png" width="130" height="30" border="0" class="abcd" /></a><a href="dangxuat.php"><img src="img/205.png" width="130" height="30" border="0" class="abcd" /></a></div></td>
    </tr>
    <tr>
      <td height="21" colspan="2">&nbsp;</td>
    </tr>
</table>
</body>
</html>
